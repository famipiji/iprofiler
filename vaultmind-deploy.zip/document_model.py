from extensions import db
from datetime import datetime
import json


class DocumentType(db.Model):
    __tablename__ = "document_types"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text, nullable=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    is_builtin = db.Column(db.Boolean, default=False, nullable=False)
    # Set when this type was synced from an external system (e.g. "ivault"),
    # with external_id holding that system's identifier (iVault classId).
    external_source = db.Column(db.String(50), nullable=True)
    external_id = db.Column(db.String(100), nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    active_prompt_version_id = db.Column(db.Integer, nullable=True, index=True)
    fields = db.relationship(
        "DocumentField",
        backref="document_type",
        lazy=True,
        cascade="all, delete-orphan",
        order_by="DocumentField.sort_order",
    )

    def to_dict(self) -> dict:
        active_label = None
        if self.active_prompt_version_id:
            apv = PromptVersion.query.get(self.active_prompt_version_id)
            active_label = apv.version_label if apv else None
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "is_active": self.is_active,
            "is_builtin": self.is_builtin,
            "external_source": self.external_source,
            "external_id": self.external_id,
            "active_prompt_version_id": self.active_prompt_version_id,
            "active_prompt_version_label": active_label,
            "created_at": self.created_at.isoformat() + "Z",
            "fields": [f.to_dict() for f in self.fields],
        }


class DocumentField(db.Model):
    __tablename__ = "document_fields"

    id = db.Column(db.Integer, primary_key=True)
    document_type_id = db.Column(db.Integer, db.ForeignKey("document_types.id"), nullable=False)
    field_label = db.Column(db.String(500), nullable=False)
    field_name = db.Column(db.String(500), nullable=False)
    field_type = db.Column(db.String(20), nullable=False, default="text")
    is_required = db.Column(db.Boolean, default=False, nullable=False)
    sort_order = db.Column(db.Integer, default=0, nullable=False)
    # NOTE: sub_columns are encoded inside field_label as "Label\tJSON_ARRAY"
    # for table-type fields — avoids needing a DB migration.
    # The sub_columns DB column is kept for compatibility but not relied on.
    sub_columns = db.Column(db.Text, nullable=True)
    # Set when this field was synced from an external system's property
    # (iVault propertyId / propertyType) — enables direct round-trip mapping.
    external_property_id = db.Column(db.String(100), nullable=True)
    external_property_type = db.Column(db.Integer, nullable=True)
    # Comma-separated label synonyms the deterministic extractor uses to locate
    # this field's value in a document (e.g. "Invoice Number, Number, Inv No").
    # User-editable in the Doc Type Manager — no code change needed per format.
    aliases = db.Column(db.Text, nullable=True)

    def to_dict(self) -> dict:
        import json as _json
        label = self.field_label or ""
        cols = None
        if self.field_type == "table":
            if "\t" in label:
                # Columns encoded inside field_label
                parts = label.split("\t", 1)
                label = parts[0]
                try:
                    cols = _json.loads(parts[1])
                except Exception:
                    cols = []
            elif self.sub_columns:
                # Fallback: legacy sub_columns DB column (if migration ran)
                try:
                    cols = _json.loads(self.sub_columns)
                except Exception:
                    cols = []
        return {
            "id": self.id,
            "document_type_id": self.document_type_id,
            "field_label": label,
            "field_name": self.field_name,
            "field_type": self.field_type,
            "is_required": self.is_required,
            "sort_order": self.sort_order,
            "sub_columns": cols,
            "aliases": self.aliases or "",
            "external_property_id": self.external_property_id,
            "external_property_type": self.external_property_type,
        }


class PromptTemplate(db.Model):
    __tablename__ = "prompt_templates"

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), nullable=False, unique=True)
    category = db.Column(db.String(50), nullable=False)   # "ocr_hint" | "structure_hint" | "classify"
    doc_type = db.Column(db.String(100), nullable=True)   # e.g. "invoice" — null for non-doc-type prompts
    label = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "key": self.key,
            "category": self.category,
            "doc_type": self.doc_type,
            "label": self.label,
            "content": self.content,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }


class TenantRetentionPolicy(db.Model):
    __tablename__ = "tenant_retention_policies"

    tenant_id = db.Column(db.String(100), primary_key=True)
    sample_ttl_days = db.Column(db.Integer, nullable=False, default=7)
    production_ttl_days = db.Column(db.Integer, nullable=False, default=30)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "tenant_id": self.tenant_id,
            "sample_ttl_days": self.sample_ttl_days,
            "production_ttl_days": self.production_ttl_days,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }


class Document(db.Model):
    __tablename__ = "documents"

    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.String(100), nullable=False, default="default", index=True)
    document_class = db.Column(db.String(20), nullable=False, default="production", index=True)
    filename = db.Column(db.String(255), nullable=False)
    unique_upload_filename = db.Column(db.String(255), nullable=True)  # UUID filename for upload
    storage_key = db.Column(db.String(255), nullable=True, index=True)
    file_type = db.Column(db.String(50))                  # image or pdf
    document_type = db.Column(db.String(100))             # invoice, receipt, etc.
    extractedText = db.Column("raw_text", db.Text(length=4294967295))
    raw_text = db.synonym("extractedText")
    fields = db.Column(db.Text)                           # JSON string of extracted fields
    field_sources = db.Column(db.Text)                    # JSON: per-field detection source (model/alias/date/not detected)
    confidence = db.Column(db.Float)
    text_blocks = db.Column(db.Text)                      # JSON list of ODL bounding boxes
    confirmed_at = db.Column(db.DateTime, nullable=True)
    pinned = db.Column(db.Boolean, default=False, nullable=False, index=True)
    pinned_at = db.Column(db.DateTime, nullable=True)
    ttl_days_override = db.Column(db.Integer, nullable=True)
    purged_at = db.Column(db.DateTime, nullable=True, index=True)
    purge_reason = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    chunks = db.relationship(
        "DocumentChunk",
        backref="document",
        lazy=True,
        cascade="all, delete-orphan",
    )

    

    def set_fields(self, fields_dict: dict):
        """Store fields dict as JSON string."""
        self.fields = json.dumps(fields_dict)

    def get_fields(self) -> dict:
        """Parse fields JSON string back to dict."""
        return json.loads(self.fields) if self.fields else {}

    def get_field_sources(self) -> dict:
        """Parse per-field detection source JSON back to dict."""
        try:
            return json.loads(self.field_sources) if self.field_sources else {}
        except Exception:
            return {}

    def set_text_blocks(self, blocks: list):
        """Store ODL text blocks (with bboxes) as JSON string."""
        self.text_blocks = json.dumps(blocks)

    def get_text_blocks(self) -> list:
        """Parse text_blocks JSON string back to list."""
        return json.loads(self.text_blocks) if self.text_blocks else []

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "tenant_id": self.tenant_id,
            "document_class": self.document_class,
            "filename": self.filename,
            "file_type": self.file_type,
            "document_type": self.document_type,
            "extractedText": self.extractedText,
            "raw_text": self.extractedText,
            "fields": self.get_fields(),
            "field_sources": self.get_field_sources(),
            "confidence": self.confidence,
            "created_at": self.created_at.isoformat() + 'Z',
            "unique_upload_filename": self.unique_upload_filename,
            "storage_key": self.storage_key,
            "confirmed_at": self.confirmed_at.isoformat() + "Z" if self.confirmed_at else None,
            "pinned": self.pinned,
            "pinned_at": self.pinned_at.isoformat() + "Z" if self.pinned_at else None,
            "ttl_days_override": self.ttl_days_override,
            "purged_at": self.purged_at.isoformat() + "Z" if self.purged_at else None,
            "purge_reason": self.purge_reason,
        }


class DocumentChunk(db.Model):
    __tablename__ = "document_chunks"

    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer, db.ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True)
    tenant_id = db.Column(db.String(100), nullable=False, index=True)
    chunk_index = db.Column(db.Integer, nullable=False)
    chunk_text = db.Column(db.Text, nullable=False)
    vector_id = db.Column(db.String(255), nullable=True, unique=True, index=True)
    chunk_hash = db.Column(db.String(64), nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "document_id": self.document_id,
            "tenant_id": self.tenant_id,
            "chunk_index": self.chunk_index,
            "chunk_text": self.chunk_text,
            "vector_id": self.vector_id,
            "chunk_hash": self.chunk_hash,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
        }


class DocumentDeletionAuditLog(db.Model):
    __tablename__ = "document_deletion_audit_logs"

    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.String(100), nullable=False, index=True)
    document_id = db.Column(db.Integer, nullable=True, index=True)
    reason = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    actor = db.Column(db.String(100), nullable=True)
    details = db.Column(db.Text, nullable=True)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "tenant_id": self.tenant_id,
            "document_id": self.document_id,
            "reason": self.reason,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "actor": self.actor,
            "details": self.details,
        }


class PromptVersion(db.Model):
    __tablename__ = "prompt_versions"

    id = db.Column(db.Integer, primary_key=True)
    document_type_id = db.Column(db.Integer, db.ForeignKey("document_types.id", ondelete="CASCADE"), nullable=False, index=True)
    prompt_kind = db.Column(db.String(50), nullable=False, default="structure_hint")
    version_major = db.Column(db.Integer, nullable=False, default=1)
    version_minor = db.Column(db.Integer, nullable=False, default=0)
    version_label = db.Column(db.String(20), nullable=False, index=True)
    prompt_text = db.Column(db.Text, nullable=False)
    parent_version_id = db.Column(db.Integer, db.ForeignKey("prompt_versions.id", ondelete="SET NULL"), nullable=True, index=True)
    change_summary = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    created_by = db.Column(db.String(100), nullable=True)
    is_active = db.Column(db.Boolean, default=False, nullable=False, index=True)

    document_type = db.relationship("DocumentType", backref=db.backref("prompt_versions", lazy=True, cascade="all, delete-orphan"))
    parent_version = db.relationship("PromptVersion", remote_side=[id], uselist=False)
    validations = db.relationship(
        "PromptVersionValidation",
        backref="prompt_version",
        lazy=True,
        cascade="all, delete-orphan",
    )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "document_type_id": self.document_type_id,
            "prompt_kind": self.prompt_kind,
            "version_major": self.version_major,
            "version_minor": self.version_minor,
            "version_label": self.version_label,
            "prompt_text": self.prompt_text,
            "parent_version_id": self.parent_version_id,
            "change_summary": self.change_summary,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "created_by": self.created_by,
            "is_active": self.is_active,
            "document_type_name": self.document_type.name if self.document_type else None,
            "validations": [v.to_dict() for v in self.validations],
        }


class PromptVersionValidation(db.Model):
    __tablename__ = "prompt_version_validations"

    id = db.Column(db.Integer, primary_key=True)
    prompt_version_id = db.Column(db.Integer, db.ForeignKey("prompt_versions.id", ondelete="CASCADE"), nullable=False, index=True)
    sample_document_id = db.Column(db.Integer, db.ForeignKey("documents.id", ondelete="SET NULL"), nullable=True, index=True)
    tenant_id = db.Column(db.String(100), nullable=False, index=True)
    extracted_result_json = db.Column(db.Text, nullable=False)
    expected_result_json = db.Column(db.Text, nullable=True)
    success = db.Column(db.Boolean, nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    created_by = db.Column(db.String(100), nullable=True)

    sample_document = db.relationship("Document", foreign_keys=[sample_document_id])

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "prompt_version_id": self.prompt_version_id,
            "sample_document_id": self.sample_document_id,
            "tenant_id": self.tenant_id,
            "extracted_result_json": self.extracted_result_json,
            "expected_result_json": self.expected_result_json,
            "success": self.success,
            "notes": self.notes,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "created_by": self.created_by,
            "sample_document_filename": self.sample_document.filename if self.sample_document else None,
        }
