import os
import time
import threading
from datetime import datetime, timedelta

from extensions import db
from document_model import Document, DocumentChunk, DocumentDeletionAuditLog, TenantRetentionPolicy


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")

_scheduler_started = False


def get_retention_policy(tenant_id: str) -> TenantRetentionPolicy:
    policy = TenantRetentionPolicy.query.filter_by(tenant_id=tenant_id).first()
    if policy is None:
        policy = TenantRetentionPolicy(
            tenant_id=tenant_id,
            sample_ttl_days=7,
            production_ttl_days=30,
        )
    return policy


def _ttl_for_document(document: Document, policy: TenantRetentionPolicy) -> int:
    if document.ttl_days_override is not None:
        return max(0, int(document.ttl_days_override))
    if (document.document_class or "production").lower() == "sample":
        return max(0, int(policy.sample_ttl_days or 7))
    return max(0, int(policy.production_ttl_days or 30))


def _expiry_anchor(document: Document) -> datetime | None:
    if (document.document_class or "production").lower() == "sample":
        return document.created_at
    return document.confirmed_at


def _document_is_expired(document: Document, now: datetime) -> bool:
    if document.pinned or document.purged_at is not None:
        return False

    policy = get_retention_policy(document.tenant_id)
    ttl_days = _ttl_for_document(document, policy)
    anchor = _expiry_anchor(document)
    if anchor is None:
        return False

    return now >= anchor + timedelta(days=ttl_days)


def _delete_raw_file(document: Document) -> None:
    filename = document.unique_upload_filename or document.storage_key
    if not filename:
        return
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(file_path):
        os.remove(file_path)


def _delete_vector_chunks(document: Document) -> None:
    try:
        from rag_service import delete_document
        delete_document(document.id, tenant_id=document.tenant_id)
    except Exception as exc:
        print(f"[Retention] Vector delete failed for doc {document.id}: {exc}")


def _delete_chunk_rows(document: Document) -> int:
    deleted = DocumentChunk.query.filter_by(document_id=document.id, tenant_id=document.tenant_id).delete(synchronize_session=False)
    return int(deleted or 0)


def _purge_document(document: Document, reason: str, now: datetime, respect_pin: bool = True) -> bool:
    if (respect_pin and document.pinned) or document.purged_at is not None:
        return False

    try:
        _delete_raw_file(document)
    except Exception as exc:
        print(f"[Retention] Raw file delete failed for doc {document.id}: {exc}")

    _delete_vector_chunks(document)
    deleted_chunks = _delete_chunk_rows(document)

    db.session.add(DocumentDeletionAuditLog(
        tenant_id=document.tenant_id,
        document_id=document.id,
        reason=reason,
        actor="system",
        details=f"purge deleted {deleted_chunks} chunk rows",
    ))
    document.purged_at = now
    document.purge_reason = reason
    db.session.commit()
    return True


def purge_expired_documents(app, now: datetime | None = None) -> dict:
    now = now or datetime.utcnow()
    with app.app_context():
        documents = Document.query.filter(Document.purged_at.is_(None)).all()
        purged = []
        skipped = []

        for document in documents:
            if document.pinned:
                skipped.append({"doc_id": document.id, "tenant_id": document.tenant_id, "reason": "pinned"})
                continue
            if not _document_is_expired(document, now):
                continue
            if _purge_document(document, "ttl_expired", now, respect_pin=True):
                purged.append({"doc_id": document.id, "tenant_id": document.tenant_id})

        return {
            "purged_count": len(purged),
            "skipped_count": len(skipped),
            "purged": purged,
            "skipped": skipped,
        }


def purge_documents(app, *, doc_id: int | None = None, tenant_id: str | None = None, reason: str = "right_to_erasure") -> dict:
    now = datetime.utcnow()
    with app.app_context():
        query = Document.query.filter(Document.purged_at.is_(None))
        if doc_id is not None:
            query = query.filter(Document.id == doc_id)
        if tenant_id is not None:
            query = query.filter(Document.tenant_id == tenant_id)

        documents = query.all()
        purged = []
        for document in documents:
            if _purge_document(document, reason, now, respect_pin=False):
                purged.append({"doc_id": document.id, "tenant_id": document.tenant_id})

        return {"purged_count": len(purged), "purged": purged}


def _seconds_until_next_midnight() -> float:
    now = datetime.utcnow()
    next_midnight = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return max(60.0, (next_midnight - now).total_seconds())


def start_retention_scheduler(app) -> None:
    global _scheduler_started
    if _scheduler_started:
        return
    if os.environ.get("DISABLE_RETENTION_SCHEDULER", "0") == "1":
        return

    _scheduler_started = True

    def _loop():
        while True:
            try:
                purge_expired_documents(app)
            except Exception as exc:
                print(f"[Retention] Scheduled purge failed: {exc}")
            time.sleep(_seconds_until_next_midnight())

    thread = threading.Thread(target=_loop, daemon=True, name="retention-purge-scheduler")
    thread.start()