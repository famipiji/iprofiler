from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
from extensions import db
from document_routes import document_bp
from settings_routes import settings_bp
from urllib.parse import quote_plus
import requests
import os
import json

IVAULT_BASE     = "http://192.168.1.18"
IVAULT_API_BASE = "https://ivaultapi2.ivaultplus.com/api"
DB_USER = 'iprofiler_user'
DB_PASS = quote_plus('P@ssw0rd')   # safely encodes @ and other special chars
DB_HOST = 'host.docker.internal'
DB_PORT = '3306'
DB_NAME = 'dms_iprofiler'

import logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
CORS(app)

@app.before_request
def log_request_headers():
    app.logger.debug(
        "\n── Incoming Request ──────────────────────────────\n"
        "%s %s\n"
        "Headers:\n%s"
        "─────────────────────────────────────────────────",
        request.method,
        request.path,
        "".join(f"  {k}: {v}\n" for k, v in request.headers),
    )

@app.errorhandler(413)
def too_large(e):
    return jsonify({"error": "File too large. Maximum upload size is 100MB."}), 413

# Config
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'SQLALCHEMY_DATABASE_URI',
    f'mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}'
)

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_recycle': 280,      # recycle connections before MySQL's wait_timeout (300s default)
    'pool_pre_ping': True,    # test connection before using it
    'pool_size': 5,
    'max_overflow': 10,
}

# Init extensions
db.init_app(app)

# Register blueprints
app.register_blueprint(document_bp, url_prefix="/api/documents")
app.register_blueprint(settings_bp, url_prefix="/api/settings")

# ── Field type hints for seeding ──────────────────────────────────────────────
_DATE_FIELDS     = {"date", "due_date", "issue_date", "expiry_date", "effective_date",
                    "maturity_date", "date_of_birth", "statement_period"}
_CURRENCY_FIELDS = {"total_amount", "subtotal", "tax", "purchase_price", "principal_amount",
                    "purchase_price", "opening_balance", "closing_balance", "total_interest_paid"}

def _field_type_for(name: str) -> str:
    n = name.strip()
    if n in _DATE_FIELDS:
        return "date"
    if n in _CURRENCY_FIELDS:
        return "currency"
    return "text"

def _label_for(name: str) -> str:
    return name.strip().replace("_", " ").title()


def seed_builtin_document_types():
    """Populate DocumentType table with all built-in types from FIELD_MAP."""
    from qwen_service import FIELD_MAP
    from document_model import DocumentType, DocumentField

    for type_name, fields_csv in FIELD_MAP.items():
        if DocumentType.query.filter_by(name=type_name).first():
            continue  # already exists — don't overwrite user edits

        dt = DocumentType(
            name=type_name,
            description=f"Built-in {_label_for(type_name)} type",
            is_active=True,
            is_builtin=True,
        )
        db.session.add(dt)
        db.session.flush()

        for i, raw_field in enumerate(fields_csv.split(",")):
            fn = raw_field.strip().replace(" ", "_").lower()
            if not fn:
                continue
            db.session.add(DocumentField(
                document_type_id=dt.id,
                field_label=_label_for(fn),
                field_name=fn,
                field_type=_field_type_for(fn),
                is_required=False,
                sort_order=i,
            ))

    db.session.commit()
    print("[Seed] Built-in document types seeded into DocumentType table")


def seed_prompt_templates():
    """Populate PromptTemplate table with editable copies of the built-in OCR/structure/classify prompts."""
    from qwen_service import OCR_HINTS, DOCUMENT_STRUCTURE_HINTS, DEFAULT_CLASSIFY_PROMPT, EXTRACT_PROMPTS
    from document_model import PromptTemplate

    def _add(key, category, doc_type, label, content):
        if PromptTemplate.query.filter_by(key=key).first():
            return  # already exists — don't overwrite user edits
        db.session.add(PromptTemplate(key=key, category=category, doc_type=doc_type, label=label, content=content))

    for type_name, hint in OCR_HINTS.items():
        _add(f"ocr_hint:{type_name}", "ocr_hint", type_name, f"OCR Focus — {_label_for(type_name)}", hint)

    for type_name, hint in DOCUMENT_STRUCTURE_HINTS.items():
        _add(f"structure_hint:{type_name}", "structure_hint", type_name, f"Extraction Structure — {_label_for(type_name)}", hint)

    _add("classify_prompt", "classify", None, "Document Classification Prompt", DEFAULT_CLASSIFY_PROMPT)

    for key, (label, content) in EXTRACT_PROMPTS.items():
        _add(key, "extract", None, label, content)

    db.session.commit()
    print("[Seed] Prompt templates seeded into PromptTemplate table")


def seed_prompt_versions():
    """Seed an initial prompt version for each document type."""
    from document_model import DocumentType
    from prompt_studio_service import ensure_prompt_version_seed

    types = DocumentType.query.order_by(DocumentType.name).all()
    for doc_type in types:
        try:
            ensure_prompt_version_seed(doc_type.name)
        except Exception as e:
            print(f"[Seed] Prompt version seed skipped for {doc_type.name}: {e}")

    print("[Seed] Prompt versions seeded for document types")


# Create tables + migrate existing schema
with app.app_context():
    db.create_all()
    try:
        with db.engine.connect() as conn:
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN tenant_id VARCHAR(100) NOT NULL DEFAULT 'default'"))
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN document_class VARCHAR(20) NOT NULL DEFAULT 'production'"))
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN storage_key VARCHAR(255)"))
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN confirmed_at DATETIME"))
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN pinned BOOLEAN NOT NULL DEFAULT 0"))
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN pinned_at DATETIME"))
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN ttl_days_override INT"))
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN purged_at DATETIME"))
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN purge_reason TEXT"))
            conn.execute(db.text("CREATE INDEX ix_documents_tenant_id ON documents (tenant_id)"))
            conn.execute(db.text("CREATE INDEX ix_documents_document_class ON documents (document_class)"))
            conn.execute(db.text("CREATE INDEX ix_documents_pinned ON documents (pinned)"))
            conn.execute(db.text("CREATE INDEX ix_documents_purged_at ON documents (purged_at)"))
            conn.commit()
        print("[Migration] Added retention columns to documents")
    except Exception:
        pass  # Columns may already exist — safe to ignore
    try:
        with db.engine.connect() as conn:
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN text_blocks TEXT"))
            conn.commit()
        print("[Migration] Added text_blocks column")
    except Exception:
        pass  # Column already exists — safe to ignore
    try:
        with db.engine.connect() as conn:
            conn.execute(db.text("ALTER TABLE documents ADD COLUMN field_sources TEXT"))
            conn.commit()
        print("[Migration] Added field_sources column to documents")
    except Exception:
        pass  # Column already exists — safe to ignore
    try:
        with db.engine.connect() as conn:
            conn.execute(db.text("ALTER TABLE document_types ADD COLUMN is_builtin BOOLEAN NOT NULL DEFAULT 0"))
            conn.commit()
        print("[Migration] Added is_builtin column")
    except Exception:
        pass  # Column already exists — safe to ignore
    try:
        with db.engine.connect() as conn:
            conn.execute(db.text("ALTER TABLE document_fields ADD COLUMN sub_columns TEXT"))
            conn.commit()
        print("[Migration] Added sub_columns column")
    except Exception:
        pass  # Column already exists — safe to ignore
    try:
        with db.engine.connect() as conn:
            conn.execute(db.text("ALTER TABLE document_fields ADD COLUMN aliases TEXT"))
            conn.commit()
        print("[Migration] Added aliases column to document_fields")
    except Exception:
        pass  # Column already exists — safe to ignore
    try:
        with db.engine.connect() as conn:
            conn.execute(db.text("ALTER TABLE document_types ADD COLUMN external_source VARCHAR(50)"))
            conn.execute(db.text("ALTER TABLE document_types ADD COLUMN external_id VARCHAR(100)"))
            conn.execute(db.text("CREATE INDEX ix_document_types_external_id ON document_types (external_id)"))
            conn.commit()
        print("[Migration] Added external_source/external_id columns to document_types")
    except Exception:
        pass  # Columns already exist — safe to ignore
    try:
        with db.engine.connect() as conn:
            conn.execute(db.text("ALTER TABLE document_fields ADD COLUMN external_property_id VARCHAR(100)"))
            conn.execute(db.text("ALTER TABLE document_fields ADD COLUMN external_property_type INT"))
            conn.commit()
        print("[Migration] Added external_property_id/external_property_type columns to document_fields")
    except Exception:
        pass  # Columns already exist — safe to ignore
    try:
        with db.engine.connect() as conn:
            conn.execute(db.text("ALTER TABLE document_types ADD COLUMN active_prompt_version_id INT"))
            conn.execute(db.text("CREATE INDEX ix_document_types_active_prompt_version_id ON document_types (active_prompt_version_id)"))
            conn.commit()
        print("[Migration] Added active_prompt_version_id column to document_types")
    except Exception:
        pass
    seed_builtin_document_types()
    seed_prompt_templates()
    seed_prompt_versions()

    try:
        from retention_service import start_retention_scheduler
        start_retention_scheduler(app)
        print("[Retention] Scheduler started")
    except Exception as e:
        print(f"[Retention] Scheduler not started: {e}")


# Serve frontend UI
@app.route('/')
def index():
    return render_template('index.html')


# ── iVault: fetch available record types ─────────────────────────────────────
# Tries the live iVault API first; falls back to a hardcoded list if unreachable.
IVAULT_FALLBACK_TYPES = [
    {'id': 'ap_invoice',     'name': 'AP Invoice',     'category': 'Finance'},
    {'id': 'ar_invoice',     'name': 'AR Invoice',     'category': 'Finance'},
    {'id': 'credit_note',    'name': 'Credit Note',    'category': 'Finance'},
    {'id': 'receipt',        'name': 'Receipt',        'category': 'Finance'},
    {'id': 'purchase_order', 'name': 'Purchase Order', 'category': 'Procurement'},
    {'id': 'contract',       'name': 'Contract',       'category': 'Legal'},
    {'id': 'bank_statement', 'name': 'Bank Statement', 'category': 'Finance'},
    {'id': 'id_card',        'name': 'ID Card',        'category': 'Identity'},
    {'id': 'passport',       'name': 'Passport',       'category': 'Identity'},
    {'id': 'resume',         'name': 'Resume / CV',    'category': 'HR'},
    {'id': 'medical_report', 'name': 'Medical Report', 'category': 'Healthcare'},
]


def _resolve_ivault_api(tenant: str) -> str:
    """Resolve iVault API base from tenant's config.json, fallback to cloud API."""
    import re as _r
    for scheme in ("https", "http"):
        try:
            cfg = requests.get(f"{scheme}://{tenant}/assets/config.json", timeout=5, verify=False)
            if cfg.ok:
                endpoint = cfg.json().get("endPoint", "").rstrip("/")
                if endpoint:
                    return endpoint
        except Exception:
            pass
    return IVAULT_API_BASE


@app.route('/api/ivault/record-types', methods=['GET'])
def get_ivault_record_types():
    """
    Fetch iVault class/record types.
    If tenant + credentials are supplied as query params, fetches live from the
    iVault API (login → GET /Class).  Otherwise returns the fallback list.
    """
    import re as _re
    raw_tenant = request.args.get('tenant', '').strip()
    tenant     = _re.sub(r'^https?://', '', raw_tenant).rstrip('/')
    username   = request.args.get('username', '').strip()
    password   = request.args.get('password', '').strip()

    if tenant and username and password:
        try:
            api_base   = _resolve_ivault_api(tenant)
            login_resp = requests.post(
                f"{api_base}/login",
                data={"username": username, "password": password, "tenant": tenant},
                timeout=10,
            )
            if login_resp.ok:
                token_data  = login_resp.json()
                auth_header = token_data.get("token_type", "Bearer") + " " + token_data["access_token"]
                class_resp  = requests.get(
                    f"{api_base}/Class/list",
                    headers={"Authorization": auth_header},
                    timeout=10,
                )
                if class_resp.ok:
                    raw = class_resp.json()
                    items = raw if isinstance(raw, list) else raw.get("data", raw.get("classes", raw.get("items", [])))
                    types = []
                    for item in items:
                        cid   = (item.get("classId") or item.get("ClassId") or
                                 item.get("id")      or item.get("Id") or "")
                        cname = (item.get("className") or item.get("ClassName") or
                                 item.get("name")    or item.get("Name") or "")
                        cat   = (item.get("category") or item.get("Category") or
                                 item.get("classType") or "")
                        if cid and cname:
                            types.append({"id": str(cid), "name": cname, "category": cat})
                    if types:
                        return jsonify({"record_types": types, "source": "ivault"})
        except Exception:
            pass  # fall through to hardcoded list

    return jsonify({"record_types": IVAULT_FALLBACK_TYPES, "source": "fallback"})


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
