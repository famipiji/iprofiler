import os
import io
import fitz           # PyMuPDF
import pytesseract
from PIL import Image


# ── Highlight colour (yellow, semi-transparent) ────────────────────────────────
HIGHLIGHT_COLOR = (1.0, 0.95, 0.0)   # RGB yellow for highlight rect stroke/fill
HIGHLIGHT_ALPHA = 0.35               # transparency


def generate_highlighted_pdf(doc_dict: dict, upload_folder: str) -> bytes:
    """
    Generate a PDF from the original image with:
        - Original image as background (full page, full quality)
        - Yellow highlight rectangle per detected word
        - Invisible selectable text per word (copyable)

    Falls back to plain image PDF if Tesseract fails, or text-only PDF if file not found.
    """
    file_type = doc_dict.get("file_type", "").lower()
    filename  = doc_dict.get("filename", "")
    raw_text  = doc_dict.get("raw_text", "") or ""

    # Prefer exact UUID filename stored at upload time
    original_path = None
    unique_fn = doc_dict.get("unique_upload_filename")
    if unique_fn:
        candidate = os.path.join(upload_folder, unique_fn)
        if os.path.isfile(candidate):
            original_path = candidate
    if not original_path:
        original_path = _find_uploaded_file(upload_folder, filename, file_type)

    if not original_path:
        return _fallback_pdf(doc_dict)

    if file_type in ("jpg", "jpeg", "png", "webp", "tif", "tiff"):
        try:
            return _highlighted_from_image(original_path, raw_text)
        except Exception as e:
            print(f"[Highlighted] Warning: highlight pass failed ({e}), using plain image PDF")
            return _image_only_pdf(original_path)
    elif file_type == "pdf":
        return _highlighted_from_pdf(original_path, raw_text)
    else:
        return _fallback_pdf(doc_dict)


# ── Core: image → highlighted PDF ─────────────────────────────────────────────

def _highlighted_from_image(image_path: str, raw_text: str) -> bytes:
    """
    Open image → run Tesseract for word coords → build PDF page with
    image background + yellow highlight rects + invisible text.
    """
    img = Image.open(image_path).convert("RGB")
    img_w, img_h = img.size

    # ── Run Tesseract to get word-level bounding boxes ─────────────────────────
    word_data = _get_word_boxes(img)

    # ── Build PDF ──────────────────────────────────────────────────────────────
    pdf = fitz.open()

    # Page size matches image aspect ratio, scaled to A4 width
    # Keep proportion: A4 width = 595pt
    PAGE_W = 595.0
    PAGE_H = PAGE_W * (img_h / img_w)
    page = pdf.new_page(width=PAGE_W, height=PAGE_H)

    # Scale factors from image pixels → PDF points
    sx = PAGE_W / img_w
    sy = PAGE_H / img_h

    # Layer 1: original image as background
    img_bytes = _pil_to_bytes(img)
    page.insert_image(
        fitz.Rect(0, 0, PAGE_W, PAGE_H),
        stream=img_bytes,
    )

    # Layer 2 + 3: highlight rect + invisible text per word
    for word in word_data:
        text = word["text"].strip()
        if not text:
            continue

        # Convert pixel coords → PDF points
        x0 = word["left"]  * sx
        y0 = word["top"]   * sy
        x1 = (word["left"] + word["width"])  * sx
        y1 = (word["top"]  + word["height"]) * sy

        rect = fitz.Rect(x0, y0, x1, y1)

        # Yellow highlight rectangle (semi-transparent)
        annot = page.add_highlight_annot(rect)
        annot.set_colors(stroke=HIGHLIGHT_COLOR)
        annot.set_opacity(HIGHLIGHT_ALPHA)
        annot.update()

        # Invisible text placed over the word (render_mode=3 = invisible)
        fontsize = max((y1 - y0) * 0.85, 4)
        try:
            page.insert_text(
                fitz.Point(x0, y1 - 1),
                text,
                fontname="helv",
                fontsize=fontsize,
                color=(1, 1, 1),
                render_mode=3,
            )
        except Exception:
            pass

    buf = io.BytesIO()
    pdf.save(buf, garbage=4, deflate=True)
    pdf.close()
    return buf.getvalue()


def _highlighted_from_pdf(pdf_path: str, raw_text: str) -> bytes:
    """
    For uploaded PDFs: render each page as image, run Tesseract,
    add highlights and invisible text layer.
    """
    src = fitz.open(pdf_path)
    out = fitz.open()

    for page_num in range(len(src)):
        src_page = src[page_num]

        # Render at 2x for Tesseract accuracy
        mat = fitz.Matrix(2, 2)
        pix = src_page.get_pixmap(matrix=mat, alpha=False)
        img_bytes = pix.tobytes("png")

        # Convert to PIL for Tesseract
        img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        img_w, img_h = img.size

        word_data = _get_word_boxes(img)

        # PDF page at original (1x) dimensions
        orig_w = src_page.rect.width
        orig_h = src_page.rect.height
        new_page = out.new_page(width=orig_w, height=orig_h)

        # Scale: rendered image coords → original PDF points
        sx = orig_w / img_w
        sy = orig_h / img_h

        # Background image
        new_page.insert_image(
            fitz.Rect(0, 0, orig_w, orig_h),
            stream=img_bytes,
        )

        # Highlights + invisible text
        for word in word_data:
            text = word["text"].strip()
            if not text:
                continue

            x0 = word["left"]  * sx
            y0 = word["top"]   * sy
            x1 = (word["left"] + word["width"])  * sx
            y1 = (word["top"]  + word["height"]) * sy

            rect = fitz.Rect(x0, y0, x1, y1)

            annot = new_page.add_highlight_annot(rect)
            annot.set_colors(stroke=HIGHLIGHT_COLOR)
            annot.set_opacity(HIGHLIGHT_ALPHA)
            annot.update()

            fontsize = max((y1 - y0) * 0.85, 4)
            try:
                new_page.insert_text(
                    fitz.Point(x0, y1 - 1),
                    text,
                    fontname="helv",
                    fontsize=fontsize,
                    color=(1, 1, 1),
                    render_mode=3,
                )
            except Exception:
                pass

    src.close()
    buf = io.BytesIO()
    out.save(buf, garbage=4, deflate=True)
    out.close()
    return buf.getvalue()


# ── Tesseract word boxes ───────────────────────────────────────────────────────

def _get_word_boxes(img: Image.Image) -> list:
    """
    Run Tesseract image_to_data() and return list of word dicts:
    [{ text, left, top, width, height, conf }, ...]
    Filters out empty words and low-confidence results.
    """
    try:
        data = pytesseract.image_to_data(
            img,
            output_type=pytesseract.Output.DICT,
            config="--psm 3"   # auto page segmentation
        )
    except Exception:
        return []

    words = []
    n = len(data["text"])
    for i in range(n):
        text = str(data["text"][i]).strip()
        conf = int(data["conf"][i]) if str(data["conf"][i]).lstrip("-").isdigit() else -1

        # Skip empty words and very low confidence (< 30)
        if not text or conf < 30:
            continue

        words.append({
            "text":   text,
            "left":   int(data["left"][i]),
            "top":    int(data["top"][i]),
            "width":  int(data["width"][i]),
            "height": int(data["height"][i]),
            "conf":   conf,
        })

    return words


# ── Helpers ────────────────────────────────────────────────────────────────────

def _pil_to_bytes(img: Image.Image, fmt: str = "PNG") -> bytes:
    buf = io.BytesIO()
    img.save(buf, format=fmt)
    return buf.getvalue()


def _find_uploaded_file(upload_folder: str, original_filename: str, file_type: str):
    """Find most recently uploaded file of matching extension."""
    if not os.path.exists(upload_folder):
        return None

    ext = file_type.lower()
    if ext == "jpeg":
        ext = "jpg"

    candidates = []
    for f in os.listdir(upload_folder):
        flow = f.lower()
        if flow.endswith(f".{ext}") or (ext == "jpg" and flow.endswith(".jpeg")):
            full = os.path.join(upload_folder, f)
            if os.path.isfile(full):
                candidates.append((os.path.getmtime(full), full))

    if not candidates:
        return None

    candidates.sort(reverse=True)
    return candidates[0][1]


def _image_only_pdf(image_path: str) -> bytes:
    """Embed image directly into a PDF page with no OCR/highlight layer."""
    img = Image.open(image_path).convert("RGB")
    img_w, img_h = img.size
    PAGE_W = 595.0
    PAGE_H = PAGE_W * (img_h / img_w)
    pdf  = fitz.open()
    page = pdf.new_page(width=PAGE_W, height=PAGE_H)
    page.insert_image(fitz.Rect(0, 0, PAGE_W, PAGE_H), stream=_pil_to_bytes(img))
    buf = io.BytesIO()
    pdf.save(buf, garbage=4, deflate=True)
    pdf.close()
    return buf.getvalue()


def _fallback_pdf(doc_dict: dict) -> bytes:
    """Plain text PDF fallback when original image not found."""
    pdf = fitz.open()
    page = pdf.new_page()

    raw_text  = doc_dict.get("raw_text", "") or "(no text available)"
    filename  = doc_dict.get("filename", "Unknown")
    doc_type  = doc_dict.get("document_type", "other")
    confidence = doc_dict.get("confidence", "")

    page.insert_text(fitz.Point(50, 50),
        "VaultMind — Highlighted Document (original not found)",
        fontsize=13, color=(0, 0.2, 0.6))
    page.insert_text(fitz.Point(50, 72),
        f"File: {filename}  |  Type: {doc_type}  |  Confidence: {confidence}",
        fontsize=9, color=(0.35, 0.47, 0.6))
    page.draw_line(fitz.Point(50, 85), fitz.Point(545, 85),
        color=(0.7, 0.85, 1.0), width=0.5)

    y = 105
    for line in raw_text.splitlines():
        if y > 800:
            page = pdf.new_page()
            y = 50
        page.insert_text(fitz.Point(50, y), line,
            fontsize=9, color=(0.04, 0.1, 0.2))
        y += 14

    buf = io.BytesIO()
    pdf.save(buf)
    pdf.close()
    return buf.getvalue()