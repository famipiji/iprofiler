import os
import fitz  # PyMuPDF


DPI = 300  # Target DPI for PDF → image conversion

def pdf_to_images(pdf_path: str, output_folder: str, dpi: int = DPI) -> list[str]:
    """
    Convert each page of a PDF to a PNG image using PyMuPDF.
    PyMuPDF base resolution is 72 DPI, so zoom = dpi / 72.
      dpi=144 → zoom 2.0 (low quality)
      dpi=200 → zoom 2.78
      dpi=300 → zoom 4.17 (default, good OCR quality)
      dpi=400 → zoom 5.56 (high quality, slower)
    """
    os.makedirs(output_folder, exist_ok=True)

    pdf = fitz.open(pdf_path)
    image_paths = []

    for i, page in enumerate(pdf):
        zoom = dpi / 72.0
        mat = fitz.Matrix(zoom, zoom)  # dpi / 72 = zoom factor
        pix = page.get_pixmap(matrix=mat)
        image_path = os.path.join(output_folder, f'page_{i + 1}.png')
        pix.save(image_path)
        image_paths.append(image_path)

    pdf.close()
    return image_paths