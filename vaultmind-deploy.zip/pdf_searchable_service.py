import os
import io
import tempfile
from datetime import datetime
import fitz  # PyMuPDF

# All possible upload folder locations (current + legacy path from old double-dirname bug)
_HERE = os.path.dirname(os.path.abspath(__file__))
_UPLOAD_FOLDERS = [
    os.path.join(_HERE, "uploads"),
    os.path.join(os.path.dirname(_HERE), "uploads"),
]


def generate_searchable_pdf(doc_dict: dict, upload_folder: str) -> bytes:  # noqa: C901
    """
    Generate a searchable PDF from the original uploaded file.

    Strategy:
    - Image files (JPG/PNG/WEBP): embed as full-page image, overlay invisible OCR text
    - PDF files: re-render each page as image, overlay invisible OCR text on top
      (this preserves the original visual while making text selectable)

    Returns PDF as bytes.
    """
    file_type    = doc_dict.get("file_type", "").lower()
    filename     = doc_dict.get("filename", "")
    raw_text     = doc_dict.get("raw_text", "") or ""
    doc_id       = doc_dict.get("id")

    # ── Locate the original uploaded file ─────────────────────────────────────
    # Flask saves files with uuid names — we search uploads folder for a match
    # by scanning for files that match the doc_id pattern, or fall back to
    # looking at the most recently modified file of the right extension.
    created_at    = doc_dict.get("created_at")
    unique_upload_filename = doc_dict.get("unique_upload_filename")
    if unique_upload_filename:
        # Search all known upload folders for the UUID-named file
        original_path = None
        for folder in [upload_folder] + _UPLOAD_FOLDERS:
            candidate = os.path.join(folder, unique_upload_filename)
            if os.path.exists(candidate):
                original_path = candidate
                break
        if not original_path:
            original_path = _find_uploaded_file(upload_folder, filename, file_type, created_at)
    else:
        original_path = _find_uploaded_file(upload_folder, filename, file_type, created_at)

    try:
        if file_type == "pdf" and original_path:
            return _searchable_from_pdf(original_path, raw_text)
        elif file_type in ("jpg", "jpeg", "png", "webp", "tif", "tiff") and original_path:
            return _searchable_from_image(original_path, raw_text)
        else:
            return _text_only_pdf(doc_dict)
    except BaseException as _top_e:
        print(f"[SearchablePDF] top-level failure ({_top_e!r}), falling back to text-only")
        import traceback; traceback.print_exc()
        return _text_only_pdf(doc_dict)


def _find_uploaded_file(upload_folder: str, original_filename: str, file_type: str, created_at_iso: str = None) -> str | None:
    """
    Find the uploaded file by searching multiple possible upload folders.
    Uses created_at timestamp to pick the best match for old records that
    don't have unique_upload_filename stored.
    """
    # Build deduplicated list of folders to search
    seen = set()
    search_folders = []
    for folder in [upload_folder] + _UPLOAD_FOLDERS:
        if folder not in seen and os.path.isdir(folder):
            seen.add(folder)
            search_folders.append(folder)

    ext = file_type.lower()
    if ext == "jpeg":
        ext = "jpg"

    candidates = []
    for folder in search_folders:
        for f in os.listdir(folder):
            if f.lower().endswith(f".{ext}") or (ext == "jpg" and f.lower().endswith(".jpeg")):
                full_path = os.path.join(folder, f)
                if os.path.isfile(full_path):
                    candidates.append((os.path.getmtime(full_path), full_path))

    if not candidates:
        return None

    if created_at_iso:
        try:
            # Parse created_at (set after processing finishes, so file mtime < created_at)
            created_at = datetime.fromisoformat(created_at_iso.replace("Z", "+00:00"))
            created_ts = created_at.timestamp()
            # Prefer files modified before created_at, pick the most recent of those
            before = [(mtime, path) for mtime, path in candidates if mtime <= created_ts]
            if before:
                before.sort(reverse=True)
                return before[0][1]
            # All files are after created_at — pick the closest one
            candidates.sort(key=lambda x: abs(x[0] - created_ts))
            return candidates[0][1]
        except Exception:
            pass

    # Final fallback: most recently modified
    candidates.sort(reverse=True)
    return candidates[0][1]


def _get_image_dpi(image_path: str) -> int:
    """Read DPI from image metadata; default to 72 if not set."""
    try:
        from PIL import Image as _PIL
        with _PIL.open(image_path) as img:
            dpi = img.info.get("dpi")
            if dpi and dpi[0] > 0:
                return int(dpi[0])
    except Exception:
        pass
    return 72


def _searchable_from_image(image_path: str, raw_text: str) -> bytes:
    """
    Create a searchable PDF from an image using ocrmypdf.
    ocrmypdf embeds the OCR text layer at mathematically exact word positions
    so Ctrl+F highlights land correctly in any PDF viewer including PDF.js.
    """
    try:
        import ocrmypdf as _ocrmypdf
    except ImportError:
        print("[SearchablePDF] ocrmypdf not installed, using fallback")
        return _searchable_from_image_fallback(image_path, raw_text)
    image_dpi = _get_image_dpi(image_path)
    out_fd, out_path = tempfile.mkstemp(suffix=".pdf")
    os.close(out_fd)
    try:
        _ocrmypdf.ocr(
            image_path, out_path,
            language="eng",
            image_dpi=image_dpi,
            skip_text=True,
            deskew=False,
            progress_bar=False,
        )
        with open(out_path, "rb") as f:
            return f.read()
    except BaseException as _e:
        print(f"[SearchablePDF] ocrmypdf failed ({_e!r}), falling back to manual embed")
        return _searchable_from_image_fallback(image_path, raw_text)
    finally:
        if os.path.exists(out_path):
            os.unlink(out_path)


def _searchable_from_image_fallback(image_path: str, raw_text: str) -> bytes:
    """Fallback: embed image + evenly-distributed text if ocrmypdf fails."""
    src_doc = fitz.open(image_path)
    w, h = src_doc[0].rect.width, src_doc[0].rect.height
    src_doc.close()
    pdf = fitz.open()
    page = pdf.new_page(width=w, height=h)
    page.insert_image(fitz.Rect(0, 0, w, h), filename=image_path, keep_proportion=False)
    _insert_invisible_text(page, raw_text, w, h)
    buf = io.BytesIO()
    pdf.save(buf, garbage=4, deflate=True)
    pdf.close()
    return buf.getvalue()


def _searchable_from_pdf(pdf_path: str, raw_text: str) -> bytes:
    """
    Create a searchable PDF from an original PDF using ocrmypdf.
    - Digital pages (already have text): preserved as-is (skip_text=True).
    - Scanned/image-only pages: Tesseract OCR text layer added at exact positions.
    Falls back to page-by-page manual processing if ocrmypdf fails.
    """
    try:
        import ocrmypdf as _ocrmypdf
    except ImportError:
        print("[SearchablePDF] ocrmypdf not installed, using fallback")
        return _searchable_from_pdf_fallback(pdf_path, raw_text)
    out_fd, out_path = tempfile.mkstemp(suffix=".pdf")
    os.close(out_fd)
    try:
        _ocrmypdf.ocr(
            pdf_path, out_path,
            language="eng",
            skip_text=True,      # keep existing text on digital pages
            deskew=False,
            progress_bar=False,
        )
        with open(out_path, "rb") as f:
            return f.read()
    except BaseException as _e:
        print(f"[SearchablePDF] ocrmypdf failed ({_e!r}), falling back to manual embed")
        return _searchable_from_pdf_fallback(pdf_path, raw_text)
    finally:
        if os.path.exists(out_path):
            os.unlink(out_path)


def _searchable_from_pdf_fallback(pdf_path: str, raw_text: str) -> bytes:
    """Fallback: re-render each page + manual text layer if ocrmypdf fails."""
    src = fitz.open(pdf_path)
    out = fitz.open()
    raw_pages = [p.strip() for p in raw_text.split("\f") if p.strip()]
    for page_num in range(len(src)):
        src_page = src[page_num]
        w, h = src_page.rect.width, src_page.rect.height
        mat = fitz.Matrix(2, 2)
        pix = src_page.get_pixmap(matrix=mat, alpha=False)
        new_page = out.new_page(width=w, height=h)
        new_page.insert_image(fitz.Rect(0, 0, w, h), stream=pix.tobytes("png"))
        words = src_page.get_text("words")
        if words:
            _insert_words_at_positions(new_page, words)
        else:
            page_text = raw_pages[page_num] if page_num < len(raw_pages) else raw_text
            _insert_invisible_text(new_page, page_text, w, h)
    src.close()
    buf = io.BytesIO()
    out.save(buf, garbage=4, deflate=True)
    out.close()
    return buf.getvalue()


def _insert_words_at_positions(page: fitz.Page, words: list):
    """
    Burn each word at its exact bbox position as an invisible text layer.
    words: list of (x0, y0, x1, y1, text, block_no, line_no, word_no)
    Baseline = bottom of bbox (y1), font size scaled to bbox height.
    """
    for word in words:
        x0, y0, x1, y1, text = word[0], word[1], word[2], word[3], word[4]
        if not text.strip():
            continue
        fontsize = max((y1 - y0) * 0.85, 4)
        try:
            page.insert_text(
                fitz.Point(x0, y1),   # baseline at bottom of word bbox
                text,
                fontname="helv",
                fontsize=fontsize,
                color=(1, 1, 1),
                render_mode=3,        # invisible text (OCR layer standard)
            )
        except Exception:
            pass


def _insert_invisible_text(page: fitz.Page, raw_text: str, page_w: float, page_h: float):
    """
    Insert OCR text as an invisible layer over the page.
    Text is rendered in white (invisible) at font size 0 effectively —
    but remains selectable and copyable in PDF readers.

    Two modes:
    - If text is short: single block centered
    - If text has lines: distribute lines vertically across the page
    """
    if not raw_text.strip():
        return

    lines = [l for l in raw_text.splitlines() if l.strip()]
    if not lines:
        return

    # Calculate font size and line spacing to fill the page
    margin_x = page_w * 0.05
    margin_y = page_h * 0.05
    usable_h = page_h - (margin_y * 2)
    usable_w = page_w - (margin_x * 2)

    # Font size: distribute lines evenly across page height
    fontsize = min(
        max(usable_h / max(len(lines), 1) * 0.75, 6),  # min 6pt
        14  # max 14pt to avoid overflow
    )

    # Use a standard font that maps well for text selection
    fontname = "helv"  # Helvetica built-in

    y = margin_y + fontsize

    for line in lines:
        if y > page_h - margin_y:
            break  # Don't overflow page

        try:
            page.insert_text(
                fitz.Point(margin_x, y),
                line,
                fontname=fontname,
                fontsize=fontsize,
                color=(1, 1, 1),   # white = visually invisible
                render_mode=3,      # 3 = invisible text (for OCR layer)
            )
        except Exception:
            pass  # Skip problematic characters

        y += fontsize * 1.4  # line height


def _text_only_pdf(doc_dict: dict) -> bytes:
    """
    Fallback: plain text PDF if original image not found.
    Still selectable and copyable.
    """
    pdf = fitz.open()
    page = pdf.new_page()  # A4

    raw_text = doc_dict.get("raw_text", "") or "(no text available)"
    filename = doc_dict.get("filename", "Unknown")
    doc_type = doc_dict.get("document_type", "other")
    confidence = doc_dict.get("confidence", "")

    # Header
    page.insert_text(fitz.Point(50, 50), "VaultMind — Searchable Document", fontsize=16, color=(0, 0.2, 0.6))
    page.insert_text(fitz.Point(50, 75), f"File: {filename}  |  Type: {doc_type}  |  Confidence: {confidence}", fontsize=9, color=(0.35, 0.47, 0.6))

    # Divider line
    page.draw_line(fitz.Point(50, 90), fitz.Point(545, 90), color=(0.7, 0.85, 1.0), width=0.5)

    # OCR text
    y = 110
    for line in raw_text.splitlines():
        if y > 800:
            page = pdf.new_page()
            y = 50
        page.insert_text(fitz.Point(50, y), line, fontsize=9, color=(0.04, 0.1, 0.2))
        y += 14

    buf = io.BytesIO()
    pdf.save(buf)
    pdf.close()
    return buf.getvalue()