import os
import uuid
import json
import time
import threading
from datetime import datetime
from flask import Blueprint, request, jsonify, Response, stream_with_context
from werkzeug.utils import secure_filename
from extensions import db
from document_model import Document, DocumentType, DocumentField
from qwen_service import process_document, _init_lm_progress
from pdf_service import pdf_to_images

document_bp = Blueprint("documents", __name__)

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "pdf"}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ?????? In-memory job store ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????
# { job_id: { "files": [...], "status": "pending/done/error" } }
jobs = {}
jobs_lock = threading.Lock()


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def update_job_step(job_id: str, file_index: int, step: str = None, step_num: float = None,
                     pages_done: int = None, pages_total: int = None):
    """Called from qwen_service to push live step label + progress to SSE."""
    if not job_id:
        return
    with jobs_lock:
        if job_id in jobs and file_index < len(jobs[job_id]["files"]):
            f = jobs[job_id]["files"][file_index]
            if step is not None:
                f["step"]     = step
            if step_num is not None:
                f["step_num"] = step_num
            if pages_done is not None:
                f["pages_done"] = pages_done
            if pages_total is not None:
                f["pages_total"] = pages_total


def _save_document_to_db(result: dict, original_filename: str, unique_filename: str, ext: str, tenant_id: str = "default", document_class: str = "production", force_document_type: str = None):
    """
    Save one processed result dict to the DB and auto-register unknown types.
    Returns the saved Document as a dict (via to_dict()).

    This is a shared helper used by both the normal single-doc path and the
    new split-PDF path (which calls it once per logical record found).
    """
    from app import app
    with app.app_context():
        # The AI may classify a document as a type that isn't registered in
        # the Document Type Manager. Rather than auto-creating a new type,
        # mark such documents as "unclassified" so they can be reviewed and
        # assigned to a type manually.
        doc_type_name = result["document_type"]
        # AI returns snake_case (e.g. "tax_invoice") but DB stores display names
        # (e.g. "Tax Invoice"). Normalize both to lowercase+spaces for comparison.
        def _norm(s):
            return s.lower().replace("_", " ").replace("-", " ").strip()

        all_active = DocumentType.query.filter_by(is_active=True).all()
        if force_document_type:
            # Caller pinned the type (e.g. a sample uploaded from the Doc Type
            # workspace). Honor it instead of AI classification so the doc
            # reliably attaches to the type being edited.
            forced = next((t for t in all_active if _norm(t.name) == _norm(force_document_type)), None)
            final_type = forced.name if forced else force_document_type
        else:
            ai_norm = _norm(doc_type_name)
            known_type = next((t for t in all_active if _norm(t.name) == ai_norm), None)
            if known_type:
                final_type = known_type.name
            else:
                final_type = "unclassified"
                print(f"[Classify] AI detected type '{doc_type_name}' which is not registered ??? marked as 'unclassified'")

        doc = Document(
            tenant_id=tenant_id or "default",
            document_class=document_class or "production",
            filename=original_filename,
            unique_upload_filename=unique_filename,
            storage_key=unique_filename,
            file_type=ext,
            document_type=final_type,
            extractedText=result.get("raw_text", ""),
            confidence=result["confidence"],
        )
        doc.set_fields(result["fields"])
        if result.get("field_sources"):
            import json as _json_fs
            doc.field_sources = _json_fs.dumps(result["field_sources"])
        if result.get("text_blocks"):
            doc.set_text_blocks(result["text_blocks"])
        db.session.add(doc)
        db.session.commit()
        return doc.to_dict()


def process_file_task(job_id: str, file_index: int, file_path: str, original_filename: str, ext: str, unique_filename: str = None, split_mode: str = "none", tenant_id: str = "default", document_class: str = "production", force_document_type: str = None):
    """
    Background thread: process a single file and update the job store.

    split_mode values:
      "none"    ??? normal single-document processing.
      "ai"      ??? AI classifies each page; consecutive same-type pages are
                  grouped into separate Document rows (process_split_pdf).
      "barcode" ??? barcode/QR pages act as separator sheets; content pages
                  between them become separate Document rows
                  (process_barcode_split_pdf).
    """
    try:
        # Update status ??? processing
        with jobs_lock:
            jobs[job_id]["files"][file_index]["status"]     = "processing"
            jobs[job_id]["files"][file_index]["started_at"] = time.time()
            jobs[job_id]["files"][file_index]["step"]       = "Starting..."
            jobs[job_id]["files"][file_index]["step_num"]   = 0

        _init_lm_progress(lambda label=None, frac=None, pages_done=None, pages_total=None:
                          update_job_step(job_id, file_index, label, frac, pages_done, pages_total))

        # ?????? Split-PDF paths (AI or Barcode) ?????????????????????????????????????????????????????????????????????????????????????????????????????????
        if split_mode in ("ai", "barcode") and ext == "pdf":
            if split_mode == "ai":
                from qwen_service import process_split_pdf
                update_job_step(job_id, file_index, "Scanning pages...", 0.05)
                split_results = process_split_pdf(file_path, UPLOAD_FOLDER)
            else:
                from qwen_service import process_barcode_split_pdf
                update_job_step(job_id, file_index, "Scanning for barcode separators...", 0.05)
                split_results = process_barcode_split_pdf(file_path, UPLOAD_FOLDER)

            sub_docs = []
            for idx, sr in enumerate(split_results):
                pages_label = f"p{sr['_split_pages'][0]}" if len(sr["_split_pages"]) == 1 \
                              else f"p{sr['_split_pages'][0]}-{sr['_split_pages'][-1]}"
                base = original_filename.rsplit(".", 1)[0]
                sub_orig_name = f"{base} ({pages_label}).pdf"
                sub_unique    = sr.get("_sub_pdf_filename") or unique_filename

                doc_dict = _save_document_to_db(sr, sub_orig_name, sub_unique, "pdf", tenant_id=tenant_id, document_class=document_class, force_document_type=force_document_type)
                sub_docs.append(doc_dict)
                print(f"[Split] Saved record {idx+1}/{len(split_results)}: {doc_dict['document_type']} ??? id={doc_dict['id']}")

            with jobs_lock:
                jobs[job_id]["files"][file_index]["status"]      = "done"
                jobs[job_id]["files"][file_index]["sub_results"] = sub_docs
                jobs[job_id]["files"][file_index]["result"]      = sub_docs[-1] if sub_docs else None
                all_done = all(f["status"] in ("done", "error") for f in jobs[job_id]["files"])
                if all_done:
                    jobs[job_id]["status"] = "done"
            return

        # ?????? Normal (single-document) path ???????????????????????????????????????????????????????????????????????????????????????????????????????????????
        result   = process_document(file_path)
        doc_dict = _save_document_to_db(result, original_filename, unique_filename, ext, tenant_id=tenant_id, document_class=document_class, force_document_type=force_document_type)

        with jobs_lock:
            jobs[job_id]["files"][file_index]["status"] = "done"
            jobs[job_id]["files"][file_index]["result"] = doc_dict
            all_done = all(f["status"] in ("done", "error") for f in jobs[job_id]["files"])
            if all_done:
                jobs[job_id]["status"] = "done"

    except Exception as e:
        with jobs_lock:
            jobs[job_id]["files"][file_index]["status"] = "error"
            jobs[job_id]["files"][file_index]["error"]  = str(e)
            all_done = all(f["status"] in ("done", "error") for f in jobs[job_id]["files"])
            if all_done:
                jobs[job_id]["status"] = "done"


# ?????? POST /api/documents/upload ????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/upload", methods=["POST"])
def upload_documents():
    """
    Multi-file upload handler.
    Accepts multiple files, queues each for background processing.
    Returns job_id to track progress via SSE.
    """
    files = request.files.getlist("files")

    if not files or all(f.filename == "" for f in files):
        return jsonify({"error": "No files provided"}), 400

    # split_mode: "none" | "ai" | "barcode"
    # "ai"      ??? AI classifies each page and groups by document type
    # "barcode" ??? barcode/QR pages are separator sheets; content pages become separate docs
    split_mode = request.form.get("split_mode", "none")
    if split_mode not in ("none", "ai", "barcode"):
        split_mode = "none"

    tenant_id = (request.form.get("tenant_id") or "default").strip() or "default"
    document_class = (request.form.get("document_class") or "production").strip().lower() or "production"
    if document_class not in ("sample", "production"):
        document_class = "production"

    # Optional: pin the saved document to a specific type (used by the Doc Type
    # workspace when uploading a sample for the type being edited), bypassing
    # AI classification so it reliably appears under that type.
    force_document_type = (request.form.get("force_document_type") or "").strip() or None

    job_id    = uuid.uuid4().hex
    job_files = []

    for file in files:
        if file.filename == "" or not allowed_file(file.filename):
            continue

        original_filename = secure_filename(file.filename)
        ext               = original_filename.rsplit(".", 1)[1].lower()
        unique_filename   = f"{uuid.uuid4().hex}.{ext}"
        file_path         = os.path.join(UPLOAD_FOLDER, unique_filename)
        file.save(file_path)

        # Split mode only applies to PDFs
        effective_mode = split_mode if ext == "pdf" else "none"

        job_files.append({
            "filename":        original_filename,
            "unique_filename": unique_filename,
            "file_path":       file_path,
            "ext":             ext,
            "split_mode":      effective_mode,
            "tenant_id":       tenant_id,
            "document_class":  document_class,
            "force_document_type": force_document_type,
            "status":      "pending",
            "step":        "Queued",
            "step_num":    0,
            "total_steps": 4,
            "started_at":  None,
            "result":      None,
            "sub_results": None,
            "error":       None,
        })

    if not job_files:
        return jsonify({"error": "No valid files found"}), 400

    # Store job
    with jobs_lock:
        jobs[job_id] = {
            "status": "processing",
            "files":  job_files,
        }

    # Launch background thread ??? sequential to avoid CPU overload
    def run_queue():
        for i, f in enumerate(job_files):
            process_file_task(job_id, i, f["file_path"], f["filename"], f["ext"], f["unique_filename"], split_mode=f.get("split_mode", "none"), tenant_id=f.get("tenant_id", "default"), document_class=f.get("document_class", "production"), force_document_type=f.get("force_document_type"))

    threading.Thread(target=run_queue, daemon=True).start()

    return jsonify({
        "success":     True,
        "job_id":      job_id,
        "total_files": len(job_files),
        "files":       [{"filename": f["filename"], "status": "pending"} for f in job_files],
    }), 202


# ?????? GET /api/documents/progress/<job_id> ??? SSE stream ???????????????????????????????????????????????????????????????????????????

@document_bp.route("/progress/<job_id>")
def progress(job_id: str):
    """
    SSE endpoint ??? streams live progress updates for a job.
    Each event carries: status, step label, step_num, total_steps, elapsed, eta.
    """
    def generate():
        last_states = {}

        while True:
            with jobs_lock:
                job = jobs.get(job_id)

            if not job:
                yield f"data: {json.dumps({'error': 'Job not found'})}\n\n"
                break

            for i, f in enumerate(job["files"]):
                # Re-emit whenever step, status, or page progress changes
                key = f"{i}_{f['status']}_{f.get('step_num', 0)}_{f.get('step', '')}_{f.get('pages_done')}_{f.get('pages_total')}"
                if last_states.get(i) != key:
                    last_states[i] = key

                    elapsed = (time.time() - f["started_at"]) if f.get("started_at") else 0
                    step_num    = f.get("step_num", 0)
                    total_steps = f.get("total_steps", 4)

                    # ETA: avg time-per-step ?? remaining steps
                    if step_num > 0 and elapsed > 0:
                        eta = max(0, int((elapsed / step_num) * (total_steps - step_num)))
                    else:
                        eta = None

                    payload = {
                        "file_index":  i,
                        "filename":    f["filename"],
                        "status":      f["status"],
                        "step":        f.get("step", ""),
                        "step_num":    step_num,
                        "total_steps": total_steps,
                        "elapsed":     int(elapsed),
                        "eta":         eta,
                        "pages_done":  f.get("pages_done"),
                        "pages_total": f.get("pages_total"),
                        "result":      f.get("result"),
                        "sub_results": f.get("sub_results"),
                        "error":       f.get("error"),
                    }
                    yield f"data: {json.dumps(payload)}\n\n"

            if job["status"] == "done":
                yield f"data: {json.dumps({'status': 'all_done'})}\n\n"
                break

            time.sleep(0.4)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control":    "no-cache",
            "X-Accel-Buffering": "no",
        }
    )


# ?????? GET /api/documents/ ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/", methods=["GET"])
def get_all_documents():
    docs = Document.query.order_by(Document.created_at.desc()).all()
    return jsonify({"documents": [d.to_dict() for d in docs]}), 200


# ?????? GET /api/documents/<id> ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>", methods=["GET"])
def get_document(doc_id):
    doc = Document.query.get_or_404(doc_id)
    return jsonify({"document": doc.to_dict()}), 200


# ?????? GET /api/documents/<id>/blocks ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/blocks", methods=["GET"])
def get_text_blocks(doc_id):
    """Return ODL bounding-box blocks for field highlight overlay."""
    doc = Document.query.get_or_404(doc_id)
    return jsonify({"blocks": doc.get_text_blocks()}), 200


# ?????? GET /api/documents/<id>/original ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/original", methods=["GET"])
def get_original_file(doc_id):
    """Serve the original uploaded file for accurate PDF.js text-layer extraction."""
    from flask import send_file
    doc = Document.query.get_or_404(doc_id)
    if not doc.unique_upload_filename:
        return jsonify({"error": "Original file not stored"}), 404
    file_path = os.path.join(UPLOAD_FOLDER, doc.unique_upload_filename)
    if not os.path.exists(file_path):
        return jsonify({"error": "Original file not found on disk"}), 404
    ext = doc.unique_upload_filename.rsplit(".", 1)[-1].lower()
    mime_map = {
        "pdf": "application/pdf",
        "jpg": "image/jpeg", "jpeg": "image/jpeg",
        "png": "image/png", "webp": "image/webp",
    }
    return send_file(file_path, mimetype=mime_map.get(ext, "application/octet-stream"))


# ?????? GET /api/documents/<id>/thumbnail ????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/thumbnail", methods=["GET"])
def get_thumbnail(doc_id):
    """Return a small JPEG thumbnail (page 1 for PDFs, resized for images)."""
    import io
    from flask import send_file
    import fitz  # PyMuPDF
    from PIL import Image

    doc = Document.query.get_or_404(doc_id)
    if not doc.unique_upload_filename:
        return jsonify({"error": "File not stored"}), 404
    file_path = os.path.join(UPLOAD_FOLDER, doc.unique_upload_filename)
    if not os.path.exists(file_path):
        return jsonify({"error": "File not found"}), 404

    ext = doc.unique_upload_filename.rsplit(".", 1)[-1].lower()
    thumb_size = (320, 440)

    try:
        if ext == "pdf":
            pdf = fitz.open(file_path)
            page = pdf[0]
            mat = fitz.Matrix(1.5, 1.5)
            pix = page.get_pixmap(matrix=mat, alpha=False)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            pdf.close()
        else:
            img = Image.open(file_path).convert("RGB")

        img.thumbnail(thumb_size, Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=75)
        buf.seek(0)
        return send_file(buf, mimetype="image/jpeg")
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ?????? DELETE /api/documents/<id> ????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>", methods=["DELETE"])
def delete_document(doc_id):
    doc = Document.query.get_or_404(doc_id)
    db.session.delete(doc)
    db.session.commit()
    return jsonify({"success": True, "message": f"Document {doc_id} deleted"}), 200


@document_bp.route("/erase", methods=["POST"])
def erase_documents():
    data = request.get_json(force=True) or {}
    doc_id = data.get("doc_id")
    tenant_id = data.get("tenant_id")
    if doc_id is None and not tenant_id:
        return jsonify({"error": "doc_id or tenant_id is required"}), 400

    try:
        doc_id = int(doc_id) if doc_id is not None else None
    except (TypeError, ValueError):
        return jsonify({"error": "doc_id must be an integer"}), 400

    from app import app
    from retention_service import purge_documents

    result = purge_documents(
        app,
        doc_id=doc_id,
        tenant_id=(tenant_id or None),
        reason=(data.get("reason") or "right_to_erasure").strip() or "right_to_erasure",
    )
    return jsonify({"success": True, **result}), 200


# ?????? PATCH /api/documents/<id> ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>", methods=["PATCH"])
def update_document(doc_id):
    doc  = Document.query.get_or_404(doc_id)
    data = request.get_json() or {}
    if "fields" in data:
        existing = doc.get_fields() or {}
        existing.update(data["fields"])
        doc.set_fields(existing)
    if "document_type" in data:
        raw_input = (data["document_type"] or "").strip()
        # Resolve to the canonical DB display name (handles "tax_invoice" ??? "Tax Invoice")
        def _norm(s):
            return s.lower().replace("_", " ").replace("-", " ").strip()
        all_active = DocumentType.query.filter_by(is_active=True).all()
        matched = next((t for t in all_active if _norm(t.name) == _norm(raw_input)), None)
        new_type = matched.name if matched else raw_input
        if new_type and new_type != doc.document_type:
            old_type = doc.document_type
            doc.document_type = new_type
            # Trigger learning from the correction
            try:
                from qwen_service import learn_type_correction
                learn_type_correction(old_type, new_type, list(doc.get_fields().keys()))
            except Exception as e:
                print(f"[PATCH] Learning update failed: {e}")
            # Re-extract fields for the new document type
            if doc.raw_text:
                try:
                    from qwen_service import extract_fields
                    new_fields = extract_fields(doc.raw_text, new_type)
                    doc.set_fields(new_fields)
                    print(f"[PATCH] Re-extracted {len(new_fields)} fields for type '{new_type}'")
                except Exception as e:
                    print(f"[PATCH] Field re-extraction failed: {e}")
    db.session.commit()
    return jsonify({"success": True, "document": doc.to_dict()}), 200


# ?????? GET /api/documents/type/<doc_type> ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/type/<string:doc_type>", methods=["GET"])
def get_by_type(doc_type):
    docs = Document.query.filter_by(document_type=doc_type).order_by(Document.created_at.desc()).all()
    return jsonify({"documents": [d.to_dict() for d in docs], "count": len(docs)}), 200


# ?????? POST /api/documents/<id>/ask ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/ask", methods=["POST"])
def ask_document(doc_id):
    doc = Document.query.get_or_404(doc_id)
    data = request.get_json() or {}
    question = (data.get("question") or "").strip()
    history  = data.get("history") or []
    client_text = (data.get("client_text") or "").strip()[:20000]
    if not question:
        return jsonify({"error": "No question provided"}), 400
    if not doc.raw_text:
        return jsonify({"error": "No text available for this document"}), 400

    # Social phrase guard — must run before intent classifier to avoid misclassification
    _SOCIAL_TOP = {
        "thank you","thanks","tq","ty","thx","thank u",
        "ok","okay","ok noted","noted","alright","got it","sure","cool","great","nice","good",
        "done","yes","no","nope","bye","goodbye","see you","cheers",
        "terima kasih","tq banyak","terima kasih banyak","sama sama","ok terima kasih",
        "oklah","boleh","baik","ok baik",
    }
    if question.lower() in _SOCIAL_TOP and not (data.get("guided_context") or {}).get("step"):
        _replies = {
            "thank you": "You're welcome! Let me know if there's anything else I can help with.",
            "thanks": "You're welcome! Anything else?",
            "tq": "You're welcome!",
            "terima kasih": "Sama-sama! Ada lagi yang boleh saya bantu?",
            "terima kasih banyak": "Sama-sama! Jangan segan untuk bertanya lagi.",
            "sama sama": "Salam! Ada lagi yang perlu dibantu?",
        }
        _reply = _replies.get(question.lower(), "You're welcome! Feel free to ask if you need anything else.")
        return jsonify({"type": "answer", "answer": _reply, "source_quote": "", "page_number": None})


    from qwen_service import detect_chat_intent, extract_fields_on_demand, answer_question, find_field_value_in_text, find_field_value_in_image, is_plausible_field_value

    from qwen_service import generate_field_extraction_rule
    import re as _re, json as _json

    def _lookup_field_id(doc_type_name, field_name):
        if not doc_type_name or not field_name:
            return None
        from document_model import DocumentType, DocumentField as _DF
        dt = DocumentType.query.filter_by(name=doc_type_name).first()
        if not dt:
            return None
        df_obj = _DF.query.filter_by(document_type_id=dt.id, field_name=field_name).first()
        return df_obj.id if df_obj else None

    def _generate_guided_rule(fn, fl, val, hint=""):
        try:
            return generate_field_extraction_rule(fn, fl, val, doc.document_type or "", doc.raw_text or "", hint)
        except Exception:
            return f"For {fn}: extract the value \"{val}\"."

    def _infer_label_for_value(raw_text, val):
        """Given a confirmed field value, find the label it's printed next to in
        the document text (e.g. "Invoice No" for "00000135"), so it can be saved
        as a Find-by label — letting the fast deterministic pass catch it on
        future documents without needing an AI call at all."""
        if not raw_text or not val:
            return None
        search_text = _re.sub(r'\s*\|\s*', '  ', raw_text)
        pat = _re.compile(
            r'([A-Za-z][A-Za-z0-9 /\-\.#]{2,30}?)\s*[:#]\s*' + _re.escape(str(val)),
            _re.IGNORECASE,
        )
        m = pat.search(search_text)
        if m:
            label = m.group(1).strip()
            if 2 <= len(label) <= 40:
                return label
        return None

    def _is_plausible_value(field_type, v, field_name="", field_label=""):
        return is_plausible_field_value(field_type, v, field_name=field_name, field_label=field_label)

    def _get_field_type(fn):
        if not doc.document_type:
            return None
        dt_obj = DocumentType.query.filter_by(name=doc.document_type).first()
        if not dt_obj:
            return None
        df_obj = DocumentField.query.filter_by(document_type_id=dt_obj.id, field_name=fn).first()
        return df_obj.field_type if df_obj else None

    def _add_alias_to_field(fn, alias):
        """De-duplicated append of `alias` to a field's Find-by labels. Returns
        the DocumentField if the alias was added (or already present), else None
        if the field/document type couldn't be resolved."""
        if not fn or not alias or not doc.document_type:
            return None
        dt_obj = DocumentType.query.filter_by(name=doc.document_type).first()
        if not dt_obj:
            return None
        df_obj = DocumentField.query.filter_by(document_type_id=dt_obj.id, field_name=fn).first()
        if not df_obj:
            return None
        existing_aliases = [a.strip() for a in (df_obj.aliases or "").split(",") if a.strip()]
        if not any(a.lower() == alias.lower() for a in existing_aliases):
            existing_aliases.append(alias)
            df_obj.aliases = ", ".join(existing_aliases)
            db.session.commit()
        return df_obj

    def _apply_rule(fn, fl, val, rule_text):
        """Append rule to the active prompt version and patch the field on this document."""
        import json as _json
        if doc.document_type and rule_text:
            from prompt_studio_service import get_active_prompt_version, create_prompt_version, activate_prompt_version
            active = get_active_prompt_version(doc.document_type)
            base = (active.prompt_text or "").strip() if active else ""
            # Replace existing rule for this field instead of duplicating
            marker = f"# Field correction rule ({fl})"
            if marker in base:
                import re as _re2
                base = _re2.sub(
                    r'# Field correction rule \(' + _re2.escape(fl) + r'\)\n.*?(?=\n#|\Z)',
                    '', base, flags=_re2.DOTALL
                ).strip()
            new_text = base + ("\n\n" if base else "") + f"# Field correction rule ({fl})\n{rule_text}"
            new_ver = create_prompt_version(
                doc.document_type, new_text,
                change_summary=f"Confirmed: {fl} ? {val}",
                created_by="guided-correction", bump="minor",
            )
            activate_prompt_version(new_ver.id)
            ver_label = new_ver.version_label
        else:
            ver_label = None
        # Patch the current document's field value
        if fn and val:
            try:
                fields = _json.loads(doc.fields or "{}") if doc.fields else {}
                fields[fn] = val
                doc.set_fields(fields)
                # Value is now known — clear any stale "not detected" badge.
                try:
                    sources = doc.get_field_sources()
                    sources[fn] = "corrected"
                    doc.field_sources = _json.dumps(sources)
                except Exception:
                    pass
                db.session.commit()
            except Exception:
                pass
            # Saving a rule for future docs (not "just this document") ??? also
            # seed a Find-by label if we can spot how `val` appears in the text,
            # so the fast deterministic pass catches it next time without AI.
            if rule_text and doc.document_type:
                try:
                    inferred_label = _infer_label_for_value(doc.raw_text or "", val)
                    if inferred_label:
                        _add_alias_to_field(fn, inferred_label)
                except Exception:
                    pass
        return ver_label

    def _infer_field_type_from_name(name):
        """Crude type guess from a field's own name/label, used when there's no
        DocumentField row yet to read a real field_type from (e.g. a brand-new
        field being added for the first time) ??? just enough to pick the right
        plausibility check (date-shaped vs amount-shaped vs generic text)."""
        n = (name or "").lower()
        if any(k in n for k in ("date", "tarikh")):
            return "date"
        if any(k in n for k in ("amount", "total", "price", "subtotal", "tax", "balance", "fee", "cost", "payment")):
            return "currency"
        return "text"

    def _smart_locate_field_value(fn, fl):
        """Try to re-locate a flagged field's correct value in the document before
        asking the user to type it manually. Cheap regex/alias pass first, then an
        LLM re-scan scoped to just this field. Also reused for brand-new fields
        being added for the first time ??? current_val is naturally empty for a key
        that doesn't exist yet, so the "must differ from current" checks below
        just pass through. Returns (value, source) or (None, None)."""
        aliases = []
        field_type = None
        if doc.document_type:
            from document_model import DocumentType as _DT_al, DocumentField as _DF_al
            dt_obj = _DT_al.query.filter_by(name=doc.document_type).first()
            if dt_obj:
                df_obj = _DF_al.query.filter_by(document_type_id=dt_obj.id, field_name=fn).first()
                if df_obj:
                    field_type = df_obj.field_type
                    if df_obj.aliases:
                        aliases = [a.strip() for a in df_obj.aliases.split(",") if a.strip()]
        if field_type is None:
            field_type = _infer_field_type_from_name(fn or fl)
        try:
            existing_fields = _json.loads(doc.fields or "{}") if doc.fields else {}
        except Exception:
            existing_fields = {}
        current_val = str(existing_fields.get(fn) or "").strip().lower()

        def _plausible(v):
            return _is_plausible_value(field_type, v, field_name=fn, field_label=fl)

        labels = [fl, fn.replace("_", " ")] + aliases
        value, matched_label = find_field_value_in_text(doc.raw_text or "", labels)
        if value and value.strip().lower() != current_val and _plausible(value):
            return value, f"found next to \"{matched_label}\" in the document"

        # The browser's own PDF.js text layer sometimes captures text the
        # server's OCR/layout pass skipped (e.g. a large stylised heading like
        # a bank name) ??? it's already loaded client-side for viewing, so this
        # costs nothing extra: same free regex search, just a second text source.
        if client_text:
            cvalue, cmatched = find_field_value_in_text(client_text, labels)
            if cvalue and cvalue.strip().lower() != current_val and _plausible(cvalue):
                return cvalue, f"found next to \"{cmatched}\" in the document (from the on-screen PDF text)"
        try:
            # Prefer the client's PDF.js text when available ??? it's proven more
            # complete than the server's raw_text for layouts (headings, logos)
            # the OCR/layout pass skips, so the AI re-scan should see it too
            # instead of guessing from an incomplete source.
            _rescan_text = client_text if client_text else (doc.raw_text or "")
            extracted = extract_fields_on_demand(_rescan_text, [fn], None, doc.document_type or "")
            ext_val = extracted.get(fn)
            if ext_val and str(ext_val).strip().lower() != current_val and _plausible(ext_val):
                return ext_val, "AI re-scanned the document"
        except Exception:
            pass

        # Last resort: some values never made it into raw_text at all (e.g. a
        # header block the initial OCR/ODL pass skipped). Re-look at the actual
        # source image/PDF with the vision model, which can see layout that
        # text extraction missed.
        if doc.unique_upload_filename:
            file_path = os.path.join(UPLOAD_FOLDER, doc.unique_upload_filename)
            if os.path.exists(file_path):
                try:
                    is_pdf = (doc.file_type or "").lower() == "pdf"
                    vision_val = find_field_value_in_image(file_path, is_pdf, fl, aliases)
                    if vision_val and vision_val.strip().lower() != current_val and _plausible(vision_val):
                        return vision_val, "found by re-reading the original document image"
                except Exception:
                    pass
        return None, None

    def _guided_start_or_suggest(fn, fl):
        """Return a value suggestion if we can auto-locate one; otherwise fall back
        to the manual "type the correct value" prompt."""
        val, source = _smart_locate_field_value(fn, fl)
        if val:
            return jsonify({"type": "guided_suggest_value", "field_name": fn, "field_label": fl,
                             "suggested_value": val, "source": source})
        return jsonify({"type": "guided_start", "field_name": fn, "field_label": fl, "explanation": "",
                         "searched": True})

    def _apply_new_field(fn, fl, val):
        """Write a newly-added field's value onto this document and return the
        same 'extraction' response shape the existing add-field flow already
        used, so the frontend's existing extraction-card + "apply to future
        docs?" handling works unchanged."""
        try:
            existing = _json.loads(doc.fields or "{}") if doc.fields else {}
        except Exception:
            existing = {}
        existing[fn] = val
        doc.set_fields(existing)
        db.session.commit()
        return jsonify({"type": "extraction", "fields": existing, "new_fields": {fn: val},
                         "new_count": 1, "suggest_future": bool(doc.document_type),
                         "doc_type": doc.document_type or ""})

    def _locate_new_field_or_ask(fn, fl):
        """Add-field counterpart to _guided_start_or_suggest: same multi-tier
        search + plausibility validation, but for a field that doesn't exist on
        this document yet ??? confirm before writing it, and offer to type it
        manually if nothing plausible turns up, instead of a dead-end message."""
        val, source = _smart_locate_field_value(fn, fl)
        if val:
            return jsonify({"type": "guided_add_suggest", "field_name": fn, "field_label": fl,
                             "suggested_value": val, "source": source})
        return jsonify({"type": "guided_add_ask_value", "field_name": fn, "field_label": fl,
                         "message": f"I couldn't find a value for \"{fl}\" anywhere in the document "
                                    "(checked the extracted text, the on-screen PDF text, and the "
                                    "image itself). Want to type it in yourself?"})

    guided_context = data.get("guided_context") or {}

    # ?? Guided multi-turn: user confirms a found value for a NEW field ???????
    if guided_context.get("step") == "confirm_add_value":
        _cv_fn = (guided_context.get("field_name") or "").strip()
        _cv_fl = guided_context.get("field_label") or _cv_fn.replace("_", " ").title()
        _cv_val = (guided_context.get("value") or "").strip()
        if _cv_fn and _cv_val:
            return _apply_new_field(_cv_fn, _cv_fl, _cv_val)
        return jsonify({"type": "answer", "answer": "Something went wrong adding that field.", "source_quote": "", "page_number": None})

    # ?? Guided multi-turn: user types the value for a NEW field manually ????
    if guided_context.get("step") == "await_add_value":
        _av_fn = (guided_context.get("field_name") or "").strip()
        _av_fl = guided_context.get("field_label") or _av_fn.replace("_", " ").title()
        _av_val = question.strip()
        if _av_fn and _av_val:
            return _apply_new_field(_av_fn, _av_fl, _av_val)
        return jsonify({"type": "answer", "answer": "Please provide a value.", "source_quote": "", "page_number": None})

    # ?? Guided multi-turn: user asks us to re-locate a specific field's value ???
    if guided_context.get("step") == "resolve_value":
        _rv_fn = (guided_context.get("field_name") or "").strip()
        _rv_fl = guided_context.get("field_label") or _rv_fn.replace("_", " ").title()
        if _rv_fn:
            return _guided_start_or_suggest(_rv_fn, _rv_fl)

    # ?? Guided multi-turn: user provides the label text for a new alias ??????
    if guided_context.get("step") == "await_alias_text":
        _aa_fn = (guided_context.get("field_name") or "").strip()
        _aa_fl = guided_context.get("field_label") or _aa_fn.replace("_", " ").title()
        _aa_alias = question.strip()
        if _aa_fn and _aa_alias:
            return jsonify({
                "type": "guided_teach_alias", "field_name": _aa_fn, "field_label": _aa_fl,
                "new_alias": _aa_alias,
                "message": f"Got it — I'll also look for \"{_aa_alias}\" when detecting \"{_aa_fl}\" "
                            "for future documents of this type. Apply this?",
            })

    # ?? Guided multi-turn: user confirms a new alias should be saved ?????????
    if guided_context.get("step") == "confirm_alias":
        _ca_fn = (guided_context.get("field_name") or "").strip()
        _ca_fl = guided_context.get("field_label") or _ca_fn.replace("_", " ").title()
        _ca_alias = (guided_context.get("new_alias") or "").strip()
        if _ca_fn and _ca_alias:
            _add_alias_to_field(_ca_fn, _ca_alias)
            # Also try applying it to THIS document right now, not just future ones.
            applied_val = None
            try:
                _found_val, _ = find_field_value_in_text(doc.raw_text or "", [_ca_alias])
                if _found_val and _is_plausible_value(_get_field_type(_ca_fn), _found_val, field_name=_ca_fn, field_label=_ca_fl):
                    _existing = _json.loads(doc.fields or "{}") if doc.fields else {}
                    _cur = str(_existing.get(_ca_fn) or "").strip().lower()
                    if _found_val.strip().lower() != _cur:
                        _existing[_ca_fn] = _found_val
                        doc.set_fields(_existing)
                        _srcs = doc.get_field_sources()
                        _srcs[_ca_fn] = "alias '" + _ca_alias + "'"
                        doc.field_sources = _json.dumps(_srcs)
                        db.session.commit()
                        applied_val = _found_val
            except Exception:
                pass
            _msg = (f"Done! I'll now also look for \"{_ca_alias}\" when detecting "
                    f"\"{_ca_fl}\" for future documents of this type.")
            if applied_val:
                _msg += f" I also found and applied it to this document: {applied_val}."
            try:
                _updated_fields = _json.loads(doc.fields or "{}") if doc.fields else {}
            except Exception:
                _updated_fields = None
            return jsonify({
                "type": "guided_alias_done", "message": _msg,
                "field_name": _ca_fn, "field_label": _ca_fl,
                "fields": _updated_fields, "field_sources": doc.get_field_sources(),
            })
        return jsonify({"type": "answer", "answer": "Something went wrong saving that label.", "source_quote": "", "page_number": None})

    # ?? Guided multi-turn: user tells us which field to add ?????????????????
    if guided_context.get("step") == "save_add_rule":
        _ar_fields = guided_context.get("field_names") or []
        _ar_dtype  = guided_context.get("doc_type") or doc.document_type or ""
        if _ar_fields and _ar_dtype:
            try:
                from document_model import DocumentType as _DT_ar, DocumentField as _DF_ar
                def _norm_ar(s): return (s or "").lower().replace("_"," ").replace("-"," ").strip()
                # Find the DocumentType by normalized name, or fuzzy match
                _dt_obj = next((t for t in _DT_ar.query.all() if _norm_ar(t.name) == _norm_ar(_ar_dtype)), None)
                if not _dt_obj:
                    _all_types = _DT_ar.query.all()
                    _tw = set(_norm_ar(_ar_dtype).split())
                    _best, _best_score = None, 0
                    for _t in _all_types:
                        _score = len(_tw & set(_norm_ar(_t.name).split()))
                        if _score > _best_score:
                            _best, _best_score = _t, _score
                    if _best and _best_score > 0:
                        _dt_obj = _best
                        print(f"[save_add_rule] fuzzy matched '{_ar_dtype}' to '{_dt_obj.name}'")
                if _dt_obj:
                    _added_fields = []
                    _existing_fnames = {f.field_name for f in (_dt_obj.fields or [])}
                    _max_sort = max((f.sort_order for f in (_dt_obj.fields or [])), default=-1)
                    for _arf in _ar_fields:
                        _arl = _arf.replace("_", " ").title()
                        if _arf not in _existing_fnames:
                            _max_sort += 1
                            _new_field = _DF_ar(
                                document_type_id=_dt_obj.id,
                                field_label=_arl,
                                field_name=_arf,
                                field_type="text",
                                is_required=False,
                                sort_order=_max_sort,
                            )
                            db.session.add(_new_field)
                            _added_fields.append(_arl)
                    if _added_fields:
                        db.session.commit()
                        _arl_names = ", ".join(_added_fields)
                        print(f"[save_add_rule] added fields {_added_fields} to type '{_dt_obj.name}'")
                        return jsonify({"type": "answer",
                                        "answer": f"Done! I'll now automatically extract **{_arl_names}** from future **{_ar_dtype}** documents. Re-upload or re-extract this document to apply it here too.",
                                        "source_quote": "", "page_number": None})
                    else:
                        return jsonify({"type": "answer", "answer": "This field is already set up for future documents.",
                                        "source_quote": "", "page_number": None})
                else:
                    print(f"[save_add_rule] doc type '{_ar_dtype}' not found in DB")
            except Exception as _e_ar:
                import traceback as _tb_ar
                print(f"[save_add_rule] error: {_e_ar}\n{_tb_ar.format_exc()}")
        return jsonify({"type": "answer", "answer": "Saved! This field will be extracted from future documents.",
                        "source_quote": "", "page_number": None})

    if guided_context.get("step") == "remove_all_confirmed":
        import json as _json_ra
        try:
            doc.set_fields({})
            db.session.commit()
        except Exception as _e_ra:
            return jsonify({"type": "answer", "answer": f"Sorry, I couldn't remove the fields: {_e_ra}", "source_quote": "", "page_number": None})
        return jsonify({"type": "remove", "removed": "all", "fields": {}})

    if guided_context.get("step") == "await_field_name_add":
        _SOCIAL = {
            'thank you','thanks','tq','ty','ok','okay','alright','noted','great',
            'good','nice','cool','done','got it','yes','no','sure','bye','goodbye',
            'terima kasih','ok terima kasih','terima kasih banyak','sama sama',
        }
        if question.strip().lower() in _SOCIAL:
            return jsonify({"type": "answer", "answer": "You're welcome! Let me know if there's anything else I can help with.", "source_quote": "", "page_number": None})
        field_names = [q.strip() for q in question.replace(",", " ").split() if q.strip()]
        # Use whole question as one field name if it reads like a label (not a list)
        if len(field_names) == 1 or " " in question.strip():
            field_names = [question.strip()]
        # Detect currency conversion requests
        import re as _re3, urllib.request as _urllib, json as _jlib
        _CURRENCIES = {
            'myr': 'MYR', 'ringgit': 'MYR',
            'usd': 'USD', 'dollar': 'USD',
            'eur': 'EUR', 'euro': 'EUR',
            'gbp': 'GBP', 'pound': 'GBP',
            'sgd': 'SGD', 'jpy': 'JPY', 'yen': 'JPY',
            'cny': 'CNY', 'yuan': 'CNY', 'rmb': 'CNY',
            'aud': 'AUD', 'cad': 'CAD', 'chf': 'CHF',
            'thb': 'THB', 'idr': 'IDR', 'php': 'PHP', 'inr': 'INR',
        }
        _ql = question.strip().lower()
        _target_cur = None
        for kw, code in _CURRENCIES.items():
            if kw in _ql:
                _target_cur = code
                break

        def _live_rate(from_cur, to_cur):
            try:
                url = f"https://open.er-api.com/v6/latest/{from_cur}"
                with _urllib.urlopen(url, timeout=5) as r:
                    data = _jlib.loads(r.read())
                return data.get("rates", {}).get(to_cur)
            except Exception:
                return None

        def _detect_doc_currency(raw):
            import re as _rxc
            if _rxc.search(r'S\$', raw): return 'SGD'
            if _rxc.search(r'A\$', raw): return 'AUD'
            if _rxc.search(r'C\$', raw): return 'CAD'
            if '$' in raw: return 'USD'
            if '€' in raw: return 'EUR'
            if '£' in raw: return 'GBP'
            if '¥' in raw: return 'JPY'
            for code in ('USD','EUR','GBP','SGD','MYR','JPY','CNY','AUD','CAD','CHF'):
                if _rxc.search(r'\b' + code + r'\b', raw):
                    return code
            return 'USD'

        if _target_cur:
            # Strip action words, prepositions, currency keywords to get the base field name
            _ACTION = r'\b(add|tambah|tolong|please|baru|new|field|create|include|' \
                      r'in|to|as|dalam|untuk|ke|sebagai)\b'
            _base = _re3.sub(r'\b(' + '|'.join(_CURRENCIES.keys()) + r')\b', '', _ql)
            _base = _re3.sub(_ACTION, '', _base)
            _base = _re3.sub(r'\s+', ' ', _base).strip()
            import sys as _sys
            print(f"[CUR_DBG] target_cur={_target_cur} base_field={repr(_base)}", file=_sys.stderr, flush=True)
            # Use extract_fields_on_demand with the cleaned base field name
            _base_fields = extract_fields_on_demand(
                doc.raw_text, [_base] if _base else field_names,
                None, doc.document_type or ""
            )
            print(f"[CUR_DBG] extract returned: {_base_fields}", file=_sys.stderr, flush=True)
            # Pick the first numeric value we find
            _raw_val = next(iter(_base_fields.values()), "") if _base_fields else ""
            _num_m = _re3.search(r'[\d,]+\.?\d*', _raw_val)
            _amount = float(_num_m.group().replace(',', '')) if _num_m else None
            # Detect source currency from the raw value first, then from doc
            _src_cur = None
            for code in ('USD','EUR','GBP','SGD','MYR','JPY','CNY','AUD','CAD','CHF'):
                if _re3.search(r'\b' + code + r'\b', _raw_val.upper()):
                    _src_cur = code
                    break
            if not _src_cur:
                for sym, code in [('S$','SGD'),('A$','AUD'),('C$','CAD'),
                                   ('$','USD'),('€','EUR'),('£','GBP'),('¥','JPY'),('RM','MYR')]:
                    if sym in _raw_val:
                        _src_cur = code
                        break
            if not _src_cur:
                _src_cur = _detect_doc_currency(doc.raw_text or "")
            print(f"[CUR_DBG] amount={_amount} src_cur={_src_cur} raw_val={repr(_raw_val)}", file=_sys.stderr, flush=True)
            if _amount and _src_cur and _src_cur != _target_cur:
                _rate = _live_rate(_src_cur, _target_cur)
                print(f"[CUR_DBG] rate {_src_cur}->{_target_cur}: {_rate}", file=_sys.stderr, flush=True)
                if _rate:
                    _converted = round(_amount * _rate, 2)
                    _val = f"{_target_cur} {_converted:,.2f}"
                else:
                    _val = _raw_val  # API unreachable fallback
            elif _amount:
                print(f"[CUR_DBG] src==target or no src, skipping conversion", file=_sys.stderr, flush=True)
                _val = _raw_val  # same currency, keep as-is
            else:
                print(f"[CUR_DBG] no amount found, val=empty", file=_sys.stderr, flush=True)
                _val = ""
            print(f"[CUR_DBG] final val={repr(_val)}", file=_sys.stderr, flush=True)
            _key = _re3.sub(r'[^a-z0-9]+', '_', _ql).strip('_')
            new_fields = {_key: _val} if _val else {}
        elif len(field_names) == 1:
            # Single named field: same multi-tier search + confirm-before-write
            # flow as field corrections, instead of writing an AI guess straight
            # to the document.
            _new_fl2 = field_names[0].replace("_", " ").title()
            _new_fn2 = _re3.sub(r'[^a-z0-9]+', '_', field_names[0].lower()).strip('_')
            if _new_fn2:
                return _locate_new_field_or_ask(_new_fn2, _new_fl2)
            new_fields = {}
        else:
            new_fields = extract_fields_on_demand(doc.raw_text, field_names, None, doc.document_type or "")
        if new_fields:
            try:
                existing = _json.loads(doc.fields or "{}") if doc.fields else {}
            except Exception:
                existing = {}
            merged = {**existing, **new_fields}
            doc.set_fields(merged)
            db.session.commit()
            _sf = bool(doc.document_type)
            return jsonify({"type": "extraction", "fields": merged, "new_fields": new_fields,
                            "new_count": len(new_fields),
                            "suggest_future": _sf, "doc_type": doc.document_type or ""})
        return jsonify({"type": "answer", "answer": f"I couldn't find \"{question.strip()}\" in this document. Check the Raw Text tab to confirm the field exists.", "source_quote": "", "page_number": None})

    # ?? Guided multi-turn: user tells us which field to remove ???????????????
    if guided_context.get("step") == "await_field_name_remove":
        try:
            existing = _json.loads(doc.fields or "{}") if doc.fields else {}
        except Exception:
            existing = {}

        # Topic-change escape: if message clearly belongs to a different intent, bail out
        def _is_topic_change(q):
            _ql = q.strip().lower()
            # Question words → QA intent
            _QW = ('what ','who ','how ','when ','where ','which ','does ','can ',
                   'apa ','siapa ','berapa ','bila ','bagaimana ','adakah ','boleh ')
            if any(_ql.startswith(w) for w in _QW): return True
            # Action words for OTHER intents
            _ADD = ('add ','tambah ','include ','create field','new field','baru field')
            if any(w in _ql for w in _ADD): return True
            # New complaint about a different field (e.g. "the invoice is wrong")
            _COMPLAINT = ('is wrong','is incorrect','is not right','is missing','looks wrong',
                          'salah','tidak betul','tak betul','not correct','is invalid')
            if any(c in _ql for c in _COMPLAINT): return True
            return False
        if not guided_context.get("confirmed") and _is_topic_change(question):
            # User changed topic — drop guided state, handle as fresh QA
            from qwen_service import answer_question as _aqe
            _res = _aqe(doc.raw_text, question, history=history)
            _res["type"] = "answer"
            return jsonify(_res)
        q_norm = question.strip().lower().replace(" ", "_")
        if not guided_context.get("confirmed"):
            matched_key = None
            for key in existing.keys():
                if key.lower().replace(" ", "_") == q_norm or key.lower() == question.strip().lower():
                    matched_key = key
                    break
            if matched_key:
                return jsonify({"type": "guided_remove_confirm", "field_name": matched_key, "field_label": matched_key.replace("_", " ").title()})
            # No exact match - try to understand what the user meant
            import re as _rem
            _qw = set(_rem.sub(r'[^a-z0-9 ]', ' ', question.strip().lower()).split())
            # If user said "X in [currency]", they mean a converted field - don't fuzzy match base field
            _CUR_WORDS = {'myr','usd','eur','gbp','sgd','jpy','cny','aud','cad','chf','thb','idr','php','inr','ringgit','dollar','euro'}
            _has_currency = bool(_qw & _CUR_WORDS)
            # Fuzzy: find a field whose words all appear in the question (skip if currency present)
            _fuzzy = None
            if not _has_currency:
                for _fk in existing.keys():
                    if set(_fk.lower().replace("_", " ").split()) & _qw:
                        _fuzzy = _fk; break
            # Escape: correction keywords mean user wants to correct, not remove
            _COR = {"wrong","salah","incorrect","not right","tak betul","tidak betul","betul","fix","change","ubah"}
            if _COR & _qw:
                if _fuzzy:
                    return _guided_start_or_suggest(_fuzzy, _fuzzy.replace("_", " ").title())
                return jsonify({"type": "answer", "answer": "It looks like you want to correct a field value. Which field is wrong and what should it be?", "source_quote": "", "page_number": None})
            # Vague remove phrases: re-ask with field list (only when no currency mismatch)
            _VAG = {"want","remove","delete","buang","hapus","field","tolong","please","a","an","the"}
            if (_VAG & _qw) and not _fuzzy and not _has_currency:
                _hint = "Current fields: " + ", ".join(list(existing.keys())[:12])
                return jsonify({"type": "guided_remove", "message": "Which field would you like to remove? " + _hint})
            # Fuzzy match found - confirm with user
            if _fuzzy:
                return jsonify({"type": "guided_remove_confirm", "field_name": _fuzzy, "field_label": _fuzzy.replace("_", " ").title()})
            # Try reconstruction: "base_in_currency" before giving up
            _cur_kw2 = next(iter(_qw & _CUR_WORDS), None) if _has_currency else None
            if _cur_kw2:
                _ql_lower2 = question.strip().lower()
                _stop2 = {"remove","delete","buang","hapus","field","the","a","an","please","tolong","want","in","to"}
                _base_words2 = _qw - _CUR_WORDS - _stop2
                _base2 = "_".join(sorted(_base_words2, key=lambda w: _ql_lower2.find(w)))
                _recon2_key = _base2 + "_in_" + _cur_kw2
                _recon2 = None
                for _ek2 in existing.keys():
                    if _ek2.lower().replace(" ", "_") == _recon2_key:
                        _recon2 = _ek2; break
                if _recon2:
                    return jsonify({"type": "guided_remove_confirm", "field_name": _recon2,
                                    "field_label": _recon2.replace("_", " ").title()})
            _flist = ", ".join(list(existing.keys())[:10])
            return jsonify({"type": "answer", "answer": f"I couldn't find that field. Available fields: {_flist}.", "source_quote": "", "page_number": None})
        removed = []
        for key in list(existing.keys()):
            if key.lower().replace(" ", "_") == q_norm or key.lower() == question.strip().lower():
                del existing[key]
                removed.append(key)
                break
        if removed:
            doc.set_fields(existing)
            # "Remove for future docs too" ??? also drop the field definition from
            # the document type's schema, so process_document stops extracting it
            # on future uploads of this type. "Just this document" (default)
            # leaves the type definition untouched, matching the pre-existing
            # behavior of only affecting the current document.
            type_removed = False
            if guided_context.get("scope") == "future" and doc.document_type:
                dt_obj = DocumentType.query.filter_by(name=doc.document_type).first()
                if dt_obj:
                    df_obj = DocumentField.query.filter_by(document_type_id=dt_obj.id, field_name=removed[0]).first()
                    if df_obj:
                        db.session.delete(df_obj)
                        type_removed = True
            db.session.commit()
            return jsonify({"type": "remove", "fields": existing, "removed": removed, "type_removed": type_removed})
        return jsonify({"type": "answer", "answer": f"I couldn't find a field named \"{question.strip()}\" to remove. Check the field names in the panel.", "source_quote": "", "page_number": None})

    # ?? Guided multi-turn: user provides the corrected value ?????????????????
    if guided_context.get("step") == "await_value":
        fn = (guided_context.get("field_name") or "").strip()
        fl = guided_context.get("field_label") or fn.replace("_", " ").title()

        # Topic-change escape: if message clearly belongs to a different intent, bail out
        def _is_topic_change(q):
            _ql = q.strip().lower()
            # Question words → QA intent
            _QW = ('what ','who ','how ','when ','where ','which ','does ','can ',
                   'apa ','siapa ','berapa ','bila ','bagaimana ','adakah ','boleh ')
            if any(_ql.startswith(w) for w in _QW): return True
            # Action words for OTHER intents
            _ADD = ('add ','tambah ','include ','create field','new field','baru field')
            if any(w in _ql for w in _ADD): return True
            # New complaint about a different field (e.g. "the invoice is wrong")
            _COMPLAINT = ('is wrong','is incorrect','is not right','is missing','looks wrong',
                          'salah','tidak betul','tak betul','not correct','is invalid')
            if any(c in _ql for c in _COMPLAINT): return True
            return False
        if fn and _is_topic_change(question):
            # User changed topic — drop guided state, handle as fresh QA
            from qwen_service import answer_question as _aqe2
            _res2 = _aqe2(doc.raw_text, question, history=history)
            _res2["type"] = "answer"
            return jsonify(_res2)
        if fn and question:
            val = question.strip()
            for pat in [
                r'^(?:it (?:should|must) be|the (?:correct )?value (?:is|should be)|should be|'
                r'sepatutnya|ia(?:lah)?|nilai(?:nya)? (?:adalah|ialah))\s+',
            ]:
                m = _re.match(pat, val, _re.IGNORECASE)
                if m:
                    val = val[m.end():].strip()
                    break
            # If the "value" is just another vague complaint, ask again
            _VAGUE = {
                'wrong','still wrong',"that's wrong","it's wrong","value is wrong",
                'not right',"that's not right","isn't right","not correct","that's not correct",
                'incorrect','still incorrect','still not right','still not correct',
                'salah','masih salah','tak betul','tidak betul','masih tidak betul',
                'still','no','nope','tidak','bukan',"that's not it","that's incorrect",
            }
            _val_lc = val.lower().rstrip('.,!?')
            _is_vague = (
                _val_lc in _VAGUE or
                _val_lc.startswith('still ') or
                _val_lc.startswith('masih ') or
                _val_lc.startswith('bukan ') or
                ('wrong' in _val_lc and len(val.split()) <= 4)
            )
            if _is_vague:
                return jsonify({
                    "type": "guided_start",
                    "field_name": fn,
                    "field_label": fl,
                    "re_ask": True,
                })
            rule_text = _generate_guided_rule(fn, fl, val)
            return jsonify({
                "type":            "guided_rule",
                "field_name":      fn,
                "field_label":     fl,
                "corrected_value": val,
                "rule_text":       rule_text,
                "field_id":        _lookup_field_id(doc.document_type, fn),
            })

    # ?? Guided multi-turn: user confirms or refines the rule ?????????????????
    if guided_context.get("step") == "await_confirmation":
        fn  = guided_context.get("field_name", "")
        fl  = guided_context.get("field_label") or fn.replace("_", " ").title()
        val = guided_context.get("corrected_value", "")
        existing_rule = guided_context.get("rule_text", "")
        q_norm = question.lower().strip()
        # Topic-escape: cancel phrases
        _CANCEL_CONF = {"never mind","nevermind","cancel","no","nope","skip","ignore","takpe","tak nak"}
        if q_norm in _CANCEL_CONF:
            return jsonify({"type": "answer", "answer": "No problem! Let me know if there's anything else I can help with.", "source_quote": "", "page_number": None})
        # Topic-escape: if user asks a new question, drop guided state and fall through
        _QW_CONF = ("what ","who ","how ","when ","where ","which ","does ","can ","show ",
                    "apa ","siapa ","berapa ","bila ","bagaimana ","add ","remove ","delete ","tambah ","buang ")
        _is_new_question = any(q_norm.startswith(w) for w in _QW_CONF) or (q_norm.startswith("is ") and "?" in question) or "?" in question
        if not _is_new_question:
            _YES = {"yes","y","ok","okay","yeah","apply","good","looks good","correct",
                    "betul","boleh","setuju","proceed","confirmed","yep","sure","go ahead","apply it"}
            is_yes = q_norm in _YES or any(q_norm.startswith(w+" ") for w in _YES)
            if is_yes:
                import json as _json_conf
                just_this_doc = guided_context.get("just_this_doc", False)
                try:
                    ver_label = _apply_rule(fn, fl, val, "" if just_this_doc else existing_rule)
                except Exception as _e_conf:
                    print(f"[await_confirmation] _apply_rule error: {_e_conf}")
                    ver_label = None
                try:
                    updated_fields = _json_conf.loads(doc.fields or "{}") if doc.fields else {}
                except Exception:
                    updated_fields = None
                updated_sources = doc.get_field_sources()
                return jsonify({"type": "guided_done", "rule_text": existing_rule,
                                "version_label": ver_label, "field_name": fn, "field_label": fl,
                                "fields": updated_fields, "field_sources": updated_sources})
            else:
                # Treat message as refinement feedback — regenerate
                rule_text = _generate_guided_rule(fn, fl, val, hint=question.strip())
                return jsonify({
                    "type":            "guided_rule",
                    "field_name":      fn,
                    "field_label":     fl,
                    "corrected_value": val,
                    "rule_text":       rule_text,
                    "field_id":        guided_context.get("field_id"),
                })

    # ?? Unified intent detection: extract / add / remove / correct / qa ?????????
    current_fields = {}
    try:
        current_fields = _json.loads(doc.fields or "{}") if doc.fields else {}
    except Exception:
        pass

    try:
        chat_intent = detect_chat_intent(question, current_fields, doc.raw_text, history)
    except Exception as e:
        print(f"[ASK] Intent detection error, falling back to QA: {e}")
        chat_intent = {"intent": "qa"}

    if chat_intent["intent"] == "chitchat":
        return jsonify({
            "type": "answer",
            "answer": "I'm here to help with this document — ask me about any of the extracted "
                      "fields, or just say if something looks wrong and I'll fix it.",
            "source_quote": "", "page_number": None,
        })

    if chat_intent["intent"] == "teach_alias":
        _ta_fn = chat_intent.get("field_name") or ""
        _ta_alias = (chat_intent.get("new_alias") or "").strip()

        def _norm_key(s):
            return (s or "").lower().replace(" ", "_").strip()

        _ta_resolved = next((k for k in current_fields.keys() if _norm_key(k) == _norm_key(_ta_fn)), None)
        if not _ta_resolved:
            _flist = ", ".join(list(current_fields.keys())[:12])
            return jsonify({"type": "answer",
                             "answer": f"Which field should I use \"{_ta_alias or 'that label'}\" for? "
                                       f"Available fields: {_flist}.",
                             "source_quote": "", "page_number": None})
        _ta_fn = _ta_resolved
        _ta_fl = _ta_fn.replace("_", " ").title()
        if not _ta_alias:
            return jsonify({"type": "guided_teach_alias_ask", "field_name": _ta_fn, "field_label": _ta_fl,
                             "message": f"Sure — what label should I also look for when detecting \"{_ta_fl}\"?"})
        return jsonify({"type": "guided_teach_alias", "field_name": _ta_fn, "field_label": _ta_fl,
                         "new_alias": _ta_alias,
                         "message": f"Got it — I'll also look for \"{_ta_alias}\" when detecting \"{_ta_fl}\" "
                                     "for future documents of this type. Apply this?"})

    if chat_intent["intent"] == "correct":
        fn  = chat_intent.get("field_name") or ""
        fl  = chat_intent.get("field_label") or fn.replace("_", " ").title()
        val = chat_intent.get("corrected_value")
        # If the model pulled a value from the document (not the user's message),
        # discard it -- the user hasn't stated the correct value yet.
        if val and val.lower().strip() not in question.lower():
            val = None
        if fn and not val:
            # Disambiguation logic:
            # - Single generic words ("name","amount","date",...) → always ask which field
            # - Multi-word terms ("invoice reference") → score by word overlap; only disambig if tied
            _HIGH_AMBIG = {"name","amount","date","number","address","total","price","company","tax"}
            # Stop words to filter out when extracting content words from user message
            _STOP_CORR = {"the","a","an","is","are","was","be","been","being","have","has","had",
                          "do","does","did","not","no","nor","please","i","want","need","but","and",
                          "wrong","incorrect","right","correct","fix","update","change","edit",
                          "salah","betul","tidak","tolong","sepatutnya","it","my","your","this","that"}
            _q_lower = question.strip().lower()
            _q_words = set(_q_lower.replace("_", " ").split())
            _q_content = {w for w in _q_words if w not in _STOP_CORR and len(w) > 1}
            _fn_all = set(fn.lower().replace("_", " ").split())
            # Match fn_all words to user words with prefix/stem tolerance
            _fn_words = set()
            for _fw in _fn_all:
                for _qw in _q_words:
                    if _fw == _qw or _fw.startswith(_qw) or _qw.startswith(_fw):
                        _fn_words.add(_fw); break
            if not _fn_words:
                _fn_words = _fn_all
            # Detect classifier mismatch: user has content words not found in fn
            # (e.g. "customer number" but fn="customer_reference" — "number" unmatched)
            _unmatched = {cw for cw in _q_content
                          if not any(cw in fw or fw in cw or cw.startswith(fw) or fw.startswith(cw)
                                     for fw in _fn_all)}
            _classifier_mismatch = len(_unmatched) > 0 and len(_q_content) > 1
            # When mismatch detected, score candidates by user content words, not fn
            _score_words = _q_content if _classifier_mismatch else _fn_words
            _is_high_ambig = bool(_fn_words & _HIGH_AMBIG) and len(_fn_words) == 1

            def _overlap_score(candidate_key):
                kw = set(candidate_key.lower().replace("_", " ").split())
                score = 0
                for fw in _score_words:
                    if any(fw in w or w in fw for w in kw):
                        score += 1
                return score

            _scored = [(k, _overlap_score(k)) for k in current_fields.keys()]
            _scored = [(k, s) for k, s in _scored if s > 0]
            _scored.sort(key=lambda x: -x[1])

            if not _scored:
                return _guided_start_or_suggest(fn, fl)

            _max_score = _scored[0][1]
            _top = [k for k, s in _scored if s == _max_score]

            if len(_top) == 1 and _max_score == len(_score_words) and not _is_high_ambig and not _classifier_mismatch:
                # Unambiguous full match — correct that field directly
                _best = _top[0]
                _best_label = _best.replace("_", " ").title()
                return _guided_start_or_suggest(_best, _best_label)

            # Ambiguous or mismatched — show disambiguation with allow_other
            _candidates = [k for k, s in _scored] if _is_high_ambig else _top
            _clabels = [c.replace("_", " ").title() for c in _candidates]
            _msg = (f"Which \"{fl}\" field do you mean? I found {len(_candidates)} possible field(s):"
                    if len(_candidates) > 1 else
                    f"Is this the \"{_clabels[0]}\" you mean, or a different one?")
            return jsonify({
                "type": "guided_disambig_correct",
                "message": _msg,
                "candidates": _candidates,
                "candidate_labels": _clabels,
                "allow_other": _is_high_ambig or _classifier_mismatch,
            })
        rule_text = _generate_guided_rule(fn, fl, val or "", chat_intent.get("rule_hint") or "")
        return jsonify({
            "type":            "guided_rule",
            "field_name":      fn,
            "field_label":     fl,
            "corrected_value": val,
            "rule_text":       rule_text,
            "field_id":        _lookup_field_id(doc.document_type, fn),
        })

    # ?? "add" with no specific field name ? ask which field ?????????????????
    if chat_intent["intent"] == "add" and not chat_intent.get("fields_to_add"):
        return jsonify({"type": "guided_add", "message": "What field would you like to add?"})

    # ?? "remove" with no specific field name ? ask which field ???????????????
    if chat_intent["intent"] == "remove" and not chat_intent.get("fields_to_remove"):
        # "remove all fields" — confirm before wiping
        _ql_ra = question.strip().lower()
        _ALL_KW = ("all fields","all field","semua field","all data","clear all","delete all","remove all","buang semua","hapus semua")
        if any(k in _ql_ra for k in _ALL_KW) and current_fields:
            _n = len(current_fields)
            return jsonify({"type": "remove_all_confirm",
                            "message": f"Are you sure you want to remove ALL {_n} field(s)? This can't be undone.",
                            "count": _n})
        field_list = list(current_fields.keys()) if current_fields else []
        hint = ""
        if field_list:
            hint = " Current fields: " + ", ".join(field_list) + "."
        return jsonify({"type": "guided_remove", "message": "Which field would you like to remove?" + hint})

    if chat_intent["intent"] == "extract":
            count_hint = chat_intent.get("count_hint")
            new_fields = extract_fields_on_demand(
                doc.raw_text,
                chat_intent.get("field_hints") or [],
                count_hint,
                doc.document_type or "",
            )
            if new_fields:
                if count_hint and len(new_fields) > count_hint:
                    new_fields = dict(list(new_fields.items())[:count_hint])
                doc.set_fields(new_fields)
                db.session.commit()
                print(f"[ASK] Extracted {len(new_fields)} fields for doc {doc.id}")
                return jsonify({
                    "type":       "extraction",
                    "fields":     new_fields,
                    "new_fields": new_fields,
                    "new_count":  len(new_fields),
                })
            else:
                result = answer_question(doc.raw_text, question, history=history)
                result["type"] = "answer"
                result["answer"] = (
                    "I couldn't extract any fields from this document. "
                    "Try specifying which fields you want, e.g. \"extract full name, NRIC, date of birth\"."
                )
                return jsonify(result)

    elif chat_intent["intent"] == "add" and chat_intent.get("fields_to_add"):
            # --- Currency conversion check ---
            import re as _re3a, urllib.request as _urla, json as _jla
            _CURRA = {
                'myr':'MYR','ringgit':'MYR','usd':'USD','dollar':'USD',
                'eur':'EUR','euro':'EUR','gbp':'GBP','pound':'GBP',
                'sgd':'SGD','jpy':'JPY','yen':'JPY','cny':'CNY','yuan':'CNY','rmb':'CNY',
                'aud':'AUD','cad':'CAD','chf':'CHF','thb':'THB','idr':'IDR','php':'PHP','inr':'INR',
            }
            _qlca = question.strip().lower()
            _tcura = None
            for _kwa, _codea in _CURRA.items():
                if _kwa in _qlca:
                    _tcura = _codea; break
            if _tcura:
                _ACTA = r'\b(add|tambah|tolong|please|baru|new|field|create|include|in|to|as|dalam|untuk|ke|sebagai)\b'
                _basea = _re3a.sub(r'\b(' + '|'.join(_CURRA.keys()) + r')\b', '', _qlca)
                _basea = _re3a.sub(_ACTA, '', _basea)
                _basea = _re3a.sub(r'\s+', ' ', _basea).strip()
                _bfa = extract_fields_on_demand(
                    doc.raw_text, [_basea] if _basea else list(chat_intent["fields_to_add"]),
                    None, doc.document_type or ""
                )
                _rvala = next(iter(_bfa.values()), "") if _bfa else ""
                _nma = _re3a.search(r'[\d,]+\.?\d*', _rvala)
                _amta = float(_nma.group().replace(',', '')) if _nma else None
                _scura = None
                for _ca in ('USD','EUR','GBP','SGD','MYR','JPY','CNY','AUD','CAD','CHF'):
                    if _re3a.search(r'\b' + _ca + r'\b', _rvala.upper()):
                        _scura = _ca; break
                if not _scura:
                    for _sym, _ca in [('S$','SGD'),('A$','AUD'),('C$','CAD'),
                                       ('$','USD'),('\u20ac','EUR'),('\u00a3','GBP'),('\u00a5','JPY'),('RM','MYR')]:
                        if _sym in _rvala:
                            _scura = _ca; break
                if not _scura:
                    import re as _rxca
                    _rt = doc.raw_text or ""
                    if _rxca.search(r'S\$', _rt): _scura = 'SGD'
                    elif _rxca.search(r'A\$', _rt): _scura = 'AUD'
                    elif _rxca.search(r'C\$', _rt): _scura = 'CAD'
                    elif '$' in _rt: _scura = 'USD'
                    elif '\u20ac' in _rt: _scura = 'EUR'
                    elif '\u00a3' in _rt: _scura = 'GBP'
                    elif '\u00a5' in _rt: _scura = 'JPY'
                    else:
                        for _cc in ('USD','EUR','GBP','SGD','MYR','JPY','CNY','AUD','CAD','CHF'):
                            if _rxca.search(r'\b' + _cc + r'\b', _rt):
                                _scura = _cc; break
                _vala = _rvala
                if _amta and _scura and _scura != _tcura:
                    try:
                        with _urla.urlopen(f"https://open.er-api.com/v6/latest/{_scura}", timeout=5) as _rr:
                            _rated = _jla.loads(_rr.read())
                        _rate = _rated.get("rates", {}).get(_tcura)
                        if _rate:
                            _vala = f"{_tcura} {round(_amta * _rate, 2):,.2f}"
                    except Exception:
                        pass
                elif _amta and not _scura:
                    pass
                if _vala:
                    _bkeya = _re3a.sub(r'[^a-z0-9]+', '_', _basea).strip('_')
                    _keya = (f"{_bkeya}_in_{_tcura.lower()}" if _bkeya
                             else _re3a.sub(r'[^a-z0-9]+', '_', _qlca).strip('_'))
                    import json as _json
                    try:
                        _exa = _json.loads(doc.fields or "{}") if doc.fields else {}
                    except Exception:
                        _exa = {}
                    _mergeda = {**_exa, _keya: _vala}
                    doc.set_fields(_mergeda)
                    import sys as _sysa
                    from extensions import db as _dba
                    _dba.session.commit()
                    print(f"[ASK] Currency conversion: {_keya}={_vala}", file=_sysa.stderr, flush=True)
                    return jsonify({"type": "extraction", "fields": _mergeda,
                                    "new_fields": {_keya: _vala}, "new_count": 1,
                                    "suggest_future": bool(doc.document_type), "doc_type": doc.document_type or ""})
            # --- End currency check, fall through to normal add ---
            # Single named field: run the same multi-tier search + confirm-before-
            # write flow used for field corrections, instead of writing an AI
            # guess straight to the document.
            if len(chat_intent["fields_to_add"]) == 1:
                _raw_name = chat_intent["fields_to_add"][0].strip()
                _new_fl = _raw_name.replace("_", " ").title()
                _new_fn = _re3a.sub(r'[^a-z0-9]+', '_', _raw_name.lower()).strip('_')
                if _new_fn:
                    return _locate_new_field_or_ask(_new_fn, _new_fl)
            new_fields = extract_fields_on_demand(
                doc.raw_text,
                chat_intent["fields_to_add"],
                None,
                doc.document_type or "",
            )
            if new_fields:
                import json as _json
                try:
                    existing = _json.loads(doc.fields or "{}") if doc.fields else {}
                except Exception:
                    existing = {}
                merged = {**existing, **new_fields}
                doc.set_fields(merged)
                db.session.commit()
                print(f"[ASK] Added {len(new_fields)} field(s) for doc {doc.id}: {list(new_fields.keys())}")
                return jsonify({
                    "type":       "extraction",
                    "fields":     merged,
                    "new_fields": new_fields,
                    "new_count":  len(new_fields),
                    "suggest_future": bool(doc.document_type),
                    "doc_type":   doc.document_type or "",
                })
            else:
                result = answer_question(doc.raw_text, question, history=history)
                result["type"] = "answer"
                result["answer"] = (
                    f"I couldn't find a value for "
                    f"{', '.join(chat_intent['fields_to_add'])} in this document. "
                    "Check the Raw Text tab to confirm the field exists."
                )
                return jsonify(result)

    elif chat_intent["intent"] == "remove" and chat_intent.get("fields_to_remove"):
            import json as _json
            try:
                existing = _json.loads(doc.fields or "{}") if doc.fields else {}
            except Exception:
                existing = {}
            # Detect "remove all" via classifier returning ["all"] or similar
            _ql_ra2 = question.strip().lower()
            _ALL_KW2 = ("all fields","all field","semua field","all data","clear all","delete all","remove all","buang semua","hapus semua")
            _fn_ra = (chat_intent["fields_to_remove"][0] or "").lower().strip()
            if (any(k in _ql_ra2 for k in _ALL_KW2) or _fn_ra in ("all","all fields","all field")) and existing:
                _n2 = len(existing)
                return jsonify({"type": "remove_all_confirm",
                                "message": f"Are you sure you want to remove ALL {_n2} field(s)? This can't be undone.",
                                "count": _n2})
            # If user said "X in [currency]" but classifier stripped the currency keyword,
            # redirect to guided flow so the user can clarify which field they mean
            _CUR_R = {'myr','usd','eur','gbp','sgd','jpy','cny','aud','cad','chf',
                      'thb','idr','php','inr','ringgit','dollar','euro'}
            _ql_r = question.strip().lower()
            _q_words_r = set(_ql_r.split())
            _has_cur_r = bool(_q_words_r & _CUR_R)
            if _has_cur_r:
                _fn_r = (chat_intent["fields_to_remove"][0] or "").lower()
                _fn_words_r = set(_fn_r.replace("_", " ").split())
                if not (_fn_words_r & _CUR_R):  # currency was stripped by classifier
                    # Reconstruct: try "fn_in_currency" (e.g. subtotal -> subtotal_in_sgd)
                    _cur_kw = next(iter(_q_words_r & _CUR_R), None)
                    _recon = None
                    if _cur_kw:
                        _recon_key = _fn_r.replace(" ", "_") + "_in_" + _cur_kw
                        for _ek in existing.keys():
                            if _ek.lower().replace(" ", "_") == _recon_key:
                                _recon = _ek; break
                    if _recon:
                        # Override with the correct field name and fall through
                        chat_intent["fields_to_remove"] = [_recon]
                    else:
                        _flist_r = ", ".join(list(existing.keys())[:12])
                        return jsonify({"type": "answer",
                                        "answer": f"I couldn't find a field called that. "
                                                  f"Your current fields are: {_flist_r}.",
                                        "source_quote": "", "page_number": None})
            removed = []
            for fn in chat_intent["fields_to_remove"]:
                if fn in existing:
                    del existing[fn]
                    removed.append(fn)
                else:
                    fn_norm = fn.lower().replace(" ", "_")
                    for key in list(existing.keys()):
                        if key.lower().replace(" ", "_") == fn_norm:
                            del existing[key]
                            removed.append(key)
                            break
            if removed:
                doc.set_fields(existing)
                db.session.commit()
                print(f"[ASK] Removed field(s) {removed} from doc {doc.id}")
                return jsonify({
                    "type":    "remove",
                    "fields":  existing,
                    "removed": removed,
                })
            else:
                result = answer_question(doc.raw_text, question, history=history)
                result["type"] = "answer"
                result["answer"] = (
                    f"I couldn't find field(s) named '{', '.join(chat_intent['fields_to_remove'])}' "
                    "in this document's fields. Check the fields panel for the exact field names."
                )
                return jsonify(result)

    # ?? Default: answer the question ??????????????????????????????????????????
    result = answer_question(doc.raw_text, question, history=history)
    result["type"] = "answer"
    return jsonify(result)


# ?????? PATCH /api/documents/<id>/fields ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/fields", methods=["PATCH"])
def patch_document_field(doc_id):
    """Overwrite a single extracted field value on this document."""
    doc = Document.query.get_or_404(doc_id)
    data = request.get_json() or {}
    field_name = (data.get("field_name") or "").strip()
    if not field_name:
        return jsonify({"error": "field_name required"}), 400
    try:
        import json as _json
        fields = _json.loads(doc.fields or "{}") if doc.fields else {}
        fields[field_name] = data.get("value")
        doc.set_fields(fields)
        db.session.commit()
        return jsonify({"ok": True, "fields": fields})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ?? DELETE /api/documents/<id>/fields/<field_name> ????????????????????????????

@document_bp.route("/<int:doc_id>/fields/<field_name>", methods=["DELETE"])
def delete_document_field(doc_id, field_name):
    """Delete a single extracted field from this document."""
    doc = Document.query.get_or_404(doc_id)
    try:
        import json as _json
        fields = _json.loads(doc.fields or "{}") if doc.fields else {}
        if field_name not in fields:
            return jsonify({"error": f"Field '{field_name}' not found"}), 404
        del fields[field_name]
        doc.set_fields(fields)
        db.session.commit()
        return jsonify({"ok": True, "fields": fields, "removed": field_name})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ?????? POST /api/documents/<id>/re-extract ???????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/re-extract", methods=["POST"])
def re_extract_fields(doc_id):
    """Re-extract all (or N) fields from the document's stored text and save them."""
    doc = Document.query.get_or_404(doc_id)
    if not doc.raw_text:
        return jsonify({"error": "No text available for this document"}), 400
    data = request.get_json() or {}
    count = data.get("count") or None
    if count:
        try:
            count = int(count)
        except (TypeError, ValueError):
            count = None

    from qwen_service import extract_fields_on_demand
    new_fields = extract_fields_on_demand(
        doc.raw_text,
        [],
        count,
        doc.document_type or "",
    )
    if not new_fields:
        return jsonify({"error": "Could not extract any fields from this document."}), 422

    # Enforce count: trim to requested number (LLM treats count as a hint, not a limit)
    if count and len(new_fields) > count:
        new_fields = dict(list(new_fields.items())[:count])

    # Replace ? not merge ? so stale/blob fields from the original extraction are cleared
    doc.set_fields(new_fields)
    db.session.commit()
    print(f"[ReExtract] Extracted {len(new_fields)} fields for doc {doc_id}")
    return jsonify({
        "type":       "extraction",
        "fields":     new_fields,
        "new_fields": new_fields,
        "new_count":  len(new_fields),
    })


# ?????? POST /api/documents/<id>/fix-extraction-rule ???????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/fix-extraction-rule", methods=["POST"])
def fix_extraction_rule(doc_id):
    """
    Generate a targeted extraction rule from a field correction and append it
    to the document type's active prompt version (structure_hint).
    """
    doc = Document.query.get_or_404(doc_id)
    data = request.get_json() or {}
    field_name     = (data.get("field_name") or "").strip()
    field_label    = (data.get("field_label") or field_name).strip()
    corrected_value = (data.get("corrected_value") or "").strip()
    rule_hint      = (data.get("rule_hint") or "").strip()
    if not field_name or not corrected_value:
        return jsonify({"error": "field_name and corrected_value required"}), 400
    if not doc.document_type:
        return jsonify({"error": "Document has no type assigned"}), 400

    try:
        from qwen_service import generate_field_extraction_rule
        rule = generate_field_extraction_rule(
            field_name, field_label, corrected_value,
            doc.document_type, doc.raw_text or "", rule_hint
        )

        # Load the current active prompt text and append the new rule
        from prompt_studio_service import get_active_prompt_version, create_prompt_version, activate_prompt_version, ensure_prompt_version_seed
        from document_model import DocumentType

        dt = DocumentType.query.filter_by(name=doc.document_type).first()
        if not dt:
            return jsonify({"error": f"Document type '{doc.document_type}' not found"}), 404

        active = get_active_prompt_version(doc.document_type)
        current_text = (active.prompt_text or "").strip() if active else ""

        # Append the new rule under a clear heading so it's visible in Prompt Studio
        separator = "\n\n" if current_text else ""
        new_text = current_text + separator + f"# Field correction rule ({field_label})\n{rule}"

        new_version = create_prompt_version(
            doc.document_type,
            prompt_text=new_text,
            change_summary=f"Auto-correction: {field_label} ??? {corrected_value}",
            created_by="ask-correction",
            bump="minor",
        )
        activate_prompt_version(new_version.id)

        return jsonify({
            "ok":   True,
            "rule": rule,
            "version_label": new_version.version_label,
        })
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"error": str(e)}), 500


# ?????? POST /api/documents/<id>/reextract ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/reextract", methods=["POST"])
def reextract_document(doc_id):
    """Re-run field extraction on an already-processed document using current doc type settings."""
    doc = Document.query.get_or_404(doc_id)
    if not doc.raw_text:
        return jsonify({"error": "No raw text available ??? cannot re-extract"}), 400
    try:
        from qwen_service import extract_fields
        new_fields = extract_fields(doc.raw_text, doc.document_type or "other")
        doc.set_fields(new_fields)
        db.session.commit()
        return jsonify({"ok": True, "fields": new_fields})
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"error": str(e)}), 500


# ?????? GET /api/documents/<id>/export ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/export", methods=["GET"])
def export_document_pdf(doc_id):
    from pdf_export_service import generate_export_pdf
    from flask import Response as FlaskResponse
    doc      = Document.query.get_or_404(doc_id)
    doc_dict = doc.to_dict()
    try:
        pdf_bytes   = generate_export_pdf(doc_dict)
        disposition = request.args.get("download", "0")
        cd          = "attachment" if disposition == "1" else "inline"
        return FlaskResponse(
            pdf_bytes,
            mimetype="application/pdf",
            headers={
                "Content-Disposition": f'{cd}; filename="vaultmind_{doc.filename}.pdf"',
                "Content-Length":      str(len(pdf_bytes)),
            }
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ?????? GET /api/documents/<id>/searchable ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/searchable", methods=["GET"])
def export_searchable_pdf(doc_id):
    from pdf_searchable_service import generate_searchable_pdf
    from flask import Response as FlaskResponse
    doc      = Document.query.get_or_404(doc_id)
    doc_dict = doc.to_dict()
    try:
        pdf_bytes   = generate_searchable_pdf(doc_dict, UPLOAD_FOLDER)
        disposition = request.args.get("download", "0")
        cd          = "attachment" if disposition == "1" else "inline"
        return FlaskResponse(
            pdf_bytes,
            mimetype="application/pdf",
            headers={
                "Content-Disposition": f'{cd}; filename="searchable_{doc.filename}.pdf"',
                "Content-Length":      str(len(pdf_bytes)),
            }
        )
    except BaseException as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


# ?????? GET /api/documents/<id>/highlighted ??????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/<int:doc_id>/highlighted", methods=["GET"])
def export_highlighted_pdf(doc_id):
    from pdf_highlighted_service import generate_highlighted_pdf
    from flask import Response as FlaskResponse
    doc      = Document.query.get_or_404(doc_id)
    doc_dict = doc.to_dict()
    try:
        pdf_bytes   = generate_highlighted_pdf(doc_dict, UPLOAD_FOLDER)
        disposition = request.args.get("download", "0")
        cd          = "attachment" if disposition == "1" else "inline"
        return FlaskResponse(
            pdf_bytes,
            mimetype="application/pdf",
            headers={
                "Content-Disposition": f'{cd}; filename="highlighted_{doc.filename}.pdf"',
                "Content-Length":      str(len(pdf_bytes)),
            }
        )
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


# ?????? GET /api/documents/rag/stats ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/rag/stats", methods=["GET"])
def rag_stats():
    try:
        from rag_service import get_stats
        return jsonify(get_stats())
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@document_bp.route("/<int:doc_id>/translate-labels", methods=["POST"])
def translate_labels(doc_id):
    """
    Translate a document's field label keys between English and the document's
    original language (auto-detected from raw_text).

    Request body:
      { "target_lang": "english" }   ??? translate non-English labels ??? English
      { "target_lang": "thai" }      ??? translate English labels ??? Thai (or any language)

    Response:
      {
        "translations": { "original label": "translated label", ... },
        "source_lang":  "thai",
        "target_lang":  "english"
      }
    """
    from qwen_service import translate_field_labels, detect_language

    doc  = Document.query.get_or_404(doc_id)
    data = request.get_json() or {}
    target_lang = (data.get("target_lang") or "english").strip().lower()

    fields = doc.get_fields() or {}
    if not fields:
        return jsonify({"translations": {}, "value_translations": {}, "source_lang": "english", "target_lang": target_lang}), 200

    # Collect label strings (field keys + table column keys)
    label_set = set()
    # Collect string values that contain non-ASCII characters (Thai, Korean, etc.)
    value_set = set()

    def _has_foreign(s):
        return isinstance(s, str) and any(ord(c) > 127 for c in s)

    for key, val in fields.items():
        label_set.add(key)
        if isinstance(val, str) and val.strip() and _has_foreign(val):
            value_set.add(val)
        elif isinstance(val, list):
            for row in val:
                if isinstance(row, dict):
                    label_set.update(row.keys())
                    for cell_val in row.values():
                        if isinstance(cell_val, str) and cell_val.strip() and _has_foreign(cell_val):
                            value_set.add(cell_val)

    # Detect the language of the raw text so we know which direction to translate
    source_lang = detect_language(doc.raw_text or "") if doc.raw_text else "english"

    try:
        translations       = translate_field_labels(list(label_set), source_lang, target_lang)
        value_translations = translate_field_labels(list(value_set), source_lang, target_lang) if value_set else {}
        return jsonify({
            "translations":       translations,
            "value_translations": value_translations,
            "source_lang":        source_lang,
            "target_lang":        target_lang,
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@document_bp.route("/logs", methods=["GET"])
def get_logs():
    """Return the in-memory pipeline log buffer (last 500 lines)."""
    from qwen_service import get_log_buffer
    lines = get_log_buffer()
    n = request.args.get("n", 100, type=int)
    return jsonify({"logs": lines[-n:], "total": len(lines)}), 200


# ?????? iVault recognize job store (mirrors the main jobs store) ???????????????????????????????????????????????????
ivault_jobs      = {}
ivault_jobs_lock = threading.Lock()


def _update_ivault_step(job_id: str, label: str, frac: float):
    """Progress callback passed to qwen_service so Vision streaming updates SSE."""
    with ivault_jobs_lock:
        if job_id in ivault_jobs:
            ivault_jobs[job_id]["step"]     = label
            ivault_jobs[job_id]["step_num"] = frac


def _run_ivault_recognize(job_id: str, file_path: str, properties: list):
    """
    Background thread ??? mirrors process_file_task() for AI Doc Processing.

    Pipeline (same steps as AI Doc Processing):
      Step 1 ??? Image prep  : PIL resize + base64 encode (inside recognize_for_ivault)
      Step 2 ??? Vision call : Qwen reads image + extracts property values in ONE step
      Step 3 ??? Stream done : SSE event pushed with {propertyId: value} result
    """
    try:
        with ivault_jobs_lock:
            ivault_jobs[job_id]["status"]   = "processing"
            ivault_jobs[job_id]["step"]     = "Preparing image..."
            ivault_jobs[job_id]["step_num"] = 0.05

        _init_lm_progress(lambda label, frac: _update_ivault_step(job_id, label, frac))

        from qwen_service import recognize_for_ivault
        values = recognize_for_ivault(file_path, properties)

        with ivault_jobs_lock:
            ivault_jobs[job_id]["status"]   = "done"
            ivault_jobs[job_id]["values"]   = values
            ivault_jobs[job_id]["step"]     = "Done"
            ivault_jobs[job_id]["step_num"] = 1.0

    except Exception as e:
        import traceback; traceback.print_exc()
        with ivault_jobs_lock:
            ivault_jobs[job_id]["status"] = "error"
            ivault_jobs[job_id]["error"]  = str(e)
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)


# ?????? POST /api/documents/ivault/recognize ???????????????????????????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/ivault/recognize", methods=["POST"])
def ivault_recognize():
    """
    iVault Recognize ??? Step 1: receive file + properties, queue job, return job_id.

    Mirrors /upload: returns job_id immediately so Android can open the SSE stream.

    Accepts multipart/form-data:
      file        ??? scanned image or PDF from scanner
      properties  ??? JSON array of classPropertyModel objects from GET /api/Class/{classId}
                    [{propertyId, propertyName, propertyType, isRequired, defaultValue}, ...]
    """
    file            = request.files.get("file")
    properties_json = request.form.get("properties", "[]")

    if not file or file.filename == "":
        return jsonify({"error": "No file provided"}), 400

    try:
        properties = json.loads(properties_json)
    except (json.JSONDecodeError, ValueError):
        return jsonify({"error": "Invalid properties JSON"}), 400

    if not isinstance(properties, list) or not properties:
        return jsonify({"error": "properties must be a non-empty array"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Unsupported file type"}), 400

    original_filename = secure_filename(file.filename)
    ext               = original_filename.rsplit(".", 1)[1].lower()
    unique_filename   = f"{uuid.uuid4().hex}.{ext}"
    file_path         = os.path.join(UPLOAD_FOLDER, unique_filename)
    file.save(file_path)

    job_id = uuid.uuid4().hex
    with ivault_jobs_lock:
        ivault_jobs[job_id] = {
            "status":   "pending",
            "step":     "Queued",
            "step_num": 0.0,
            "values":   None,
            "error":    None,
        }

    threading.Thread(
        target=_run_ivault_recognize,
        args=(job_id, file_path, properties),
        daemon=True,
    ).start()

    return jsonify({"success": True, "job_id": job_id}), 202


# ?????? GET /api/documents/ivault/progress/<job_id> ??? SSE stream ???????????????????????????????????????????????????

@document_bp.route("/ivault/progress/<job_id>")
def ivault_progress(job_id: str):
    """
    Shared SSE stream for all iVault background jobs.

    Handles two job types:
      recognize        ??? final event includes: values = {propertyId: value}
      detect_separators ??? final event includes: separators_found, documents

    Events always carry: status, step, step_num (0.0???1.0).
    """
    def generate():
        last_state = None
        while True:
            with ivault_jobs_lock:
                job = ivault_jobs.get(job_id)

            if not job:
                yield f"data: {json.dumps({'error': 'Job not found'})}\n\n"
                break

            state = f"{job['status']}_{job.get('step_num', 0):.2f}_{job.get('step', '')}"
            if state != last_state:
                last_state = state
                payload = {
                    "status":   job["status"],
                    "step":     job.get("step", ""),
                    "step_num": job.get("step_num", 0.0),
                }
                if job["status"] == "done":
                    job_type = job.get("job_type", "recognize")
                    if job_type == "detect_separators":
                        payload["separators_found"] = job.get("separators_found", False)
                        payload["documents"]        = job.get("documents", [])
                    else:
                        payload["values"] = job.get("values")
                elif job["status"] == "error":
                    payload["error"] = job.get("error", "Unknown error")
                yield f"data: {json.dumps(payload)}\n\n"

            if job["status"] in ("done", "error"):
                break

            time.sleep(0.4)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ?????? iVault class helpers ??????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

_IVAULT_FALLBACK_CLASSES = [
    {"classId": None, "className": "AP Invoice"},
    {"classId": None, "className": "AR Invoice"},
    {"classId": None, "className": "Credit Note"},
    {"classId": None, "className": "Receipt"},
    {"classId": None, "className": "Purchase Order"},
    {"classId": None, "className": "Contract"},
    {"classId": None, "className": "Bank Statement"},
    {"classId": None, "className": "ID Card"},
    {"classId": None, "className": "Passport"},
    {"classId": None, "className": "Resume"},
    {"classId": None, "className": "Medical Report"},
]


def _norm_class(s: str) -> str:
    """Normalize a class/type name for fuzzy matching."""
    import re as _re
    return _re.sub(r"[^a-z0-9]", "", str(s).lower())


def _fetch_ivault_classes(tenant: str, username: str, password: str) -> list:
    """
    Fetch iVault class list.  Returns list of {"classId": str, "className": str}.
    Falls back to _IVAULT_FALLBACK_CLASSES on any failure or missing credentials.
    """
    if not (tenant and username and password):
        return _IVAULT_FALLBACK_CLASSES

    import requests as _req
    import re as _re

    tenant = _re.sub(r'^https?://', '', tenant).rstrip('/')

    # Resolve API base (mirrors document_routes._resolve_ivault_api)
    api_base = None
    for scheme in ("https", "http"):
        try:
            cfg = _req.get(f"{scheme}://{tenant}/assets/config.json", timeout=5, verify=False)
            if cfg.ok:
                endpoint = cfg.json().get("endPoint", "").rstrip("/")
                if endpoint:
                    api_base = endpoint
                    break
        except Exception:
            pass
    if not api_base:
        api_base = "https://ivaultapi2.ivaultplus.com/api"

    try:
        lr = _req.post(
            f"{api_base}/login",
            data={"username": username, "password": password, "tenant": tenant},
            timeout=15, verify=False,
        )
        if not lr.ok:
            return _IVAULT_FALLBACK_CLASSES
        token = lr.json().get("token_type", "Bearer") + " " + lr.json()["access_token"]

        cr = _req.get(
            f"{api_base}/Class/list",
            headers={"Authorization": token, "Tenant": tenant},
            timeout=15, verify=False,
        )
        if cr.ok:
            raw = cr.json()
            items = raw if isinstance(raw, list) else raw.get("data", raw.get("classes", raw.get("items", [])))
            classes = []
            for item in items:
                cid = (item.get("classId") or item.get("ClassId") or
                       item.get("id")      or item.get("Id") or "")
                cname = (item.get("className") or item.get("ClassName") or
                         item.get("name")    or item.get("Name") or "")
                if cname:
                    classes.append({"classId": str(cid) if cid else None, "className": cname})
            if classes:
                return classes
    except Exception as e:
        print(f"[DetectSep] Failed to fetch iVault classes: {e}")

    return _IVAULT_FALLBACK_CLASSES


def _match_ivault_class(detected_type: str, classes: list) -> dict:
    """
    Fuzzy-match a snake_case detected_type to the closest iVault class.
    Returns {"classId": ..., "className": ...} or None if no reasonable match.
    """
    needle = _norm_class(detected_type)
    best, best_score = None, 0

    for cls in classes:
        hay = _norm_class(cls["className"])
        # Score: ratio of shared characters (simple overlap)
        score = sum(1 for c in needle if c in hay) / max(len(needle), 1)
        # Boost for full substring match in either direction
        if needle in hay or hay in needle:
            score += 0.5
        if score > best_score:
            best_score = score
            best = cls

    # Require at least 40 % overlap to avoid wild mismatches
    return best if best_score >= 0.4 else None


# ?????? Background worker ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

def _run_ivault_detect_separators(
    job_id: str,
    file_path: str,
    tenant: str,
    username: str,
    password: str,
):
    """
    Background thread for POST /api/documents/ivault/detect-separators.

    1. Calls detect_separator_groups() ??? barcode-first, AI fallback.
    2. Fetches iVault classes (live if credentials supplied, else fallback list).
    3. Maps each detected group to the closest iVault class.
    4. Stores result in ivault_jobs for the SSE stream to pick up.
    """
    try:
        with ivault_jobs_lock:
            ivault_jobs[job_id]["status"]   = "processing"
            ivault_jobs[job_id]["step"]     = "Starting..."
            ivault_jobs[job_id]["step_num"] = 0.02

        _init_lm_progress(lambda label, frac: _update_ivault_step(job_id, label, frac))

        from qwen_service import detect_separator_groups
        groups = detect_separator_groups(file_path)

        # Fetch iVault class list for mapping
        _update_ivault_step(job_id, "Matching document types...", 0.95)
        classes = _fetch_ivault_classes(tenant, username, password)

        documents = []
        for grp in groups:
            matched = _match_ivault_class(grp["detected_type"], classes)
            documents.append({
                "pages":     grp["pages"],
                "classId":   matched["classId"]   if matched else None,
                "className": matched["className"] if matched else grp["detected_type"],
            })

        separators_found = len(groups) > 1

        with ivault_jobs_lock:
            ivault_jobs[job_id]["status"]          = "done"
            ivault_jobs[job_id]["step"]            = "Done"
            ivault_jobs[job_id]["step_num"]        = 1.0
            ivault_jobs[job_id]["separators_found"] = separators_found
            ivault_jobs[job_id]["documents"]       = documents

        print(f"[DetectSep] Done ??? {len(documents)} group(s), separators_found={separators_found}")

    except Exception as e:
        import traceback; traceback.print_exc()
        with ivault_jobs_lock:
            ivault_jobs[job_id]["status"] = "error"
            ivault_jobs[job_id]["error"]  = str(e)
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)


# ?????? POST /api/documents/ivault/detect-separators ??????????????????????????????????????????????????????????????????????????????????????????

@document_bp.route("/ivault/detect-separators", methods=["POST"])
def ivault_detect_separators():
    """
    Detect document boundaries inside a multi-record PDF.

    Accepts multipart/form-data:
      file       ??? the PDF to analyse (required)
      tenant     ??? iVault tenant host, e.g. "demo.ivaultplus.com" (optional)
      username   ??? iVault username (optional)
      password   ??? iVault password (optional)

    When tenant/username/password are supplied the backend fetches the live
    iVault class list to resolve classId values.  Without them it falls back
    to a built-in class name list (classId will be null).

    Returns:
      {"success": true, "job_id": "<hex>"}

    Progress + result via SSE:
      GET /api/documents/ivault/progress/<job_id>
    """
    file = request.files.get("file")
    if not file or file.filename == "":
        return jsonify({"error": "No file provided"}), 400
    if not allowed_file(file.filename):
        return jsonify({"error": "Unsupported file type ??? PDF required"}), 400

    ext = secure_filename(file.filename).rsplit(".", 1)[-1].lower()
    if ext != "pdf":
        return jsonify({"error": "Only PDF files are supported"}), 400

    unique_filename = f"{uuid.uuid4().hex}.pdf"
    file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
    file.save(file_path)

    tenant   = request.form.get("tenant",   "").strip()
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")

    job_id = uuid.uuid4().hex
    with ivault_jobs_lock:
        ivault_jobs[job_id] = {
            "job_type":        "detect_separators",
            "status":          "pending",
            "step":            "Queued",
            "step_num":        0.0,
            "separators_found": None,
            "documents":       None,
            "error":           None,
        }

    threading.Thread(
        target=_run_ivault_detect_separators,
        args=(job_id, file_path, tenant, username, password),
        daemon=True,
    ).start()

    return jsonify({"success": True, "job_id": job_id}), 202


@document_bp.route("/learned-structures", methods=["GET"])
def get_learned_structures():
    """Fetch all learned document type structures."""
    try:
        from qwen_service import load_learned_structures
        structures = load_learned_structures()
        return jsonify({
            "learned_structures": structures,
            "count": len(structures)
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ?????? POST /api/documents/<id>/export-ivault ????????????????????????????????????????????????????????????????????????????????????????????????????????????

IVAULT_API_BASE_DEFAULT = "https://ivaultapi2.ivaultplus.com/api"


def _resolve_ivault_api(tenant: str) -> str:
    """
    Resolve the iVault API base URL for a given tenant.
    Tries fetching /assets/config.json from the tenant's web app first.
    Falls back to the cloud API with the tenant as subdomain context.
    """
    import requests as _r
    for scheme in ("https", "http"):
        try:
            cfg = _r.get(f"{scheme}://{tenant}/assets/config.json", timeout=5, verify=False)
            if cfg.ok:
                endpoint = cfg.json().get("endPoint", "").rstrip("/")
                if endpoint:
                    return endpoint
        except Exception:
            pass
    return IVAULT_API_BASE_DEFAULT


class IVaultAuthError(Exception):
    """Raised by _ivault_session() on login failure. Carries a user-facing message and HTTP status."""
    def __init__(self, message: str, status: int = 502):
        super().__init__(message)
        self.message = message
        self.status = status


def _ivault_session(tenant: str, username: str, password: str):
    """
    Log into the iVault API for the given tenant.

    Returns (session, auth_header, api_base) on success.
    Raises IVaultAuthError(message, status) on failure.
    """
    import requests as req
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    api_base = _resolve_ivault_api(tenant)
    print(f"[iVault] resolved API base: {api_base} for tenant: {tenant}")

    session = req.Session()
    try:
        login_resp = session.post(
            f"{api_base}/login",
            data={"username": username, "password": password, "tenant": tenant},
            timeout=15,
            verify=False,
        )
        if login_resp.status_code == 400:
            login_resp = session.post(
                f"{api_base}/login",
                data={"username": username, "password": password},
                timeout=15,
                verify=False,
            )
        if not login_resp.ok:
            raise IVaultAuthError(login_resp.text or "Invalid iVault credentials", 401)
        token_data = login_resp.json()
        if not isinstance(token_data, dict) or "access_token" not in token_data:
            raise IVaultAuthError(f"Unexpected iVault login response (no access_token): {str(token_data)[:200]}", 502)
        auth_header = token_data.get("token_type", "Bearer") + " " + token_data["access_token"]
        print(f"[iVault] login OK, cookies: {dict(session.cookies)}")
    except IVaultAuthError:
        raise
    except (KeyError, ValueError, AttributeError):
        raise IVaultAuthError("Unexpected login response from iVault API", 502)
    except req.exceptions.ConnectionError:
        raise IVaultAuthError(f"Cannot connect to iVault API at {api_base}", 502)
    except req.exceptions.Timeout:
        raise IVaultAuthError("iVault login timed out", 504)
    except req.exceptions.HTTPError as e:
        raise IVaultAuthError(f"iVault login failed with HTTP {e.response.status_code}", 502)

    return session, auth_header, api_base


@document_bp.route("/<int:doc_id>/export-ivault", methods=["POST"])
def export_to_ivault(doc_id):
    """
    Upload a processed document to iVault under a user-selected record type.

    Body: {
      "record_type_id": "<iVault classId GUID>",
      "tenant":         "demo.ivaultplus.com",
      "username":       "sys.admin",
      "password":       "secret"
    }

    Flow:
      1. Resolve API base from tenant config.json
      2. POST /api/login  ??? Bearer token
      3. GET  /api/Class/{id} ??? class property definitions
      4. POST /api/document/upload ??? multipart with files[0] format
    """
    import requests as req
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    doc  = Document.query.get_or_404(doc_id)
    data = request.get_json() or {}

    record_type_id = data.get("record_type_id", "").strip()
    username       = data.get("username", "").strip()
    password       = data.get("password", "")
    import re as _re
    raw_tenant = data.get("tenant", "").strip()
    tenant = _re.sub(r'^https?://', '', raw_tenant).rstrip('/')

    if not record_type_id:
        return jsonify({"error": "record_type_id required"}), 400
    if not tenant or not username or not password:
        return jsonify({"error": "iVault credentials (tenant, username, password) required"}), 400

    # ?????? Step 1: Login ??? use a Session so cookies from login carry into upload ??????
    try:
        session, auth_header, api_base = _ivault_session(tenant, username, password)
    except IVaultAuthError as e:
        return jsonify({"error": e.message}), e.status

    # ?????? Step 2: Resolve file info ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????
    if not doc.unique_upload_filename:
        return jsonify({"error": "No source file stored for this document"}), 404

    file_path = os.path.join(UPLOAD_FOLDER, doc.unique_upload_filename)
    if not os.path.exists(file_path):
        return jsonify({"error": "Source file not found on disk"}), 404

    ext = doc.unique_upload_filename.rsplit(".", 1)[-1].lower()
    mime_map = {
        "pdf":  "application/pdf",
        "jpg":  "image/jpeg", "jpeg": "image/jpeg",
        "png":  "image/png",  "webp": "image/webp",
    }
    mime = mime_map.get(ext, "application/octet-stream")
    file_size = os.path.getsize(file_path)
    display_name = doc.filename or os.path.basename(file_path)

    # ?????? Step 2b: Searchable PDF (optional) ?????????????????????????????????????????????????????????????????????????????????????????????????????????
    # When "searchable": true is passed, generate a PDF with the raw_text
    # embedded as an invisible text layer so iVault can index/search its content.
    upload_bytes = None
    if data.get("searchable") and doc.raw_text:
        try:
            from pdf_searchable_service import generate_searchable_pdf
            upload_bytes = generate_searchable_pdf(doc.to_dict(), UPLOAD_FOLDER)
            base_name = display_name.rsplit(".", 1)[0]
            display_name = f"{base_name}.pdf"
            ext  = "pdf"
            mime = "application/pdf"
            file_size = len(upload_bytes)
            print(f"[iVault] Searchable PDF generated: {file_size} bytes")
        except Exception as _se:
            print(f"[iVault] Searchable PDF generation failed ({_se}), uploading original")

    # ?????? Step 3: Fetch class property definitions ??????????????????????????????????????????????????????????????????????????????????????????
    class_props = []
    class_name  = ""
    try:
        cp_resp = session.get(
            f"{api_base}/Class/{record_type_id}",
            headers={"Authorization": auth_header, "Tenant": tenant},
            timeout=15,
            verify=False,
        )
        if cp_resp.ok:
            cp_body = cp_resp.json()
            class_props = cp_body.get("classPropertyModels", [])
            class_name  = cp_body.get("className") or cp_body.get("name") or ""
    except Exception:
        pass

    # ?????? Step 3b: If the selected record type differs from what iProfiler
    # detected, sync it to a local DocumentType and re-run extraction with
    # forced_document_type so the fields match this record type's schema
    # (same mechanism used by /ivault/import) before mapping to iVault
    # properties below.
    reextracted_fields = None
    try:
        from settings_routes import _sync_ivault_document_type_with_session
        target_doc_type = _sync_ivault_document_type_with_session(
            record_type_id, class_name or "iVault Class", session, auth_header, api_base, tenant
        )
        db.session.commit()
        if target_doc_type.name != doc.document_type:
            print(f"[iVault] Re-extracting fields for record type '{target_doc_type.name}' (was '{doc.document_type}')")
            result = process_document(file_path, forced_document_type=target_doc_type.name)
            reextracted_fields = result.get("fields") or {}
            doc.document_type = target_doc_type.name
            doc.set_fields(reextracted_fields)
            if result.get("raw_text"):
                doc.raw_text = result["raw_text"]
            doc.confidence = result.get("confidence", doc.confidence)
            db.session.commit()
    except Exception as _sync_err:
        print(f"[iVault] Re-extraction for selected record type skipped: {_sync_err}")

    # ?????? Step 4: Map document fields ??? iVault property GUIDs ??????????????????????????????????????????????????????
    def _norm(s):
        return _re.sub(r'[^a-z0-9]', '', str(s).lower())

    doc_fields = reextracted_fields if reextracted_fields is not None else (doc.get_fields() or {})
    field_lookup = {
        _norm(k): str(v)
        for k, v in doc_fields.items()
        if v is not None and not isinstance(v, (dict, list))
    }
    # Allow iVault properties named "content", "raw_text", "ocr_text", or
    # "full_text" to receive the extracted raw text ??? useful if the iVault
    # class exposes a memo/long-text field for full-text search metadata.
    if doc.raw_text:
        for _alias in ("content", "rawtext", "ocrtext", "fulltext", "ocr", "text"):
            field_lookup.setdefault(_alias, doc.raw_text[:4000])

    # Allow iVault properties named "record_type", "class_id", "document_type"
    # etc. to receive the iVault classId (and class name) of the record type
    # the document was filed under for this export ??? lets iProfiler's
    # extraction surface which record type a document was matched to.
    for _alias in ("recordtype", "recordtypeid", "classid", "documenttype", "doctype"):
        field_lookup.setdefault(_alias, record_type_id)
    if class_name:
        for _alias in ("recordtypename", "documenttypename", "classname"):
            field_lookup.setdefault(_alias, class_name)

    def _match_value(prop_name):
        n = _norm(prop_name)
        if n in field_lookup:
            return field_lookup[n]
        for key, val in field_lookup.items():
            if n in key or key in n:
                return val
        return ""

    # ?????? Step 5: Upload with files[0] indexed multipart format ????????????????????????????????????????????????
    form_data = {
        "files[0][fileName]":  display_name,
        "files[0][extension]": mime,
        "files[0][size]":      str(file_size),
        "files[0][ext]":       ext,
        "files[0][classId]":   record_type_id,
    }
    for i, prop in enumerate(class_props):
        p = f"files[0][properties][{i}]"
        form_data[f"{p}[classId]"]      = record_type_id
        form_data[f"{p}[propertyId]"]   = prop.get("propertyId", "")
        form_data[f"{p}[propertyType]"] = str(prop.get("type", 0))
        form_data[f"{p}[value]"]        = _match_value(prop.get("propertyName", ""))

    print(f"[iVault] uploading to: {api_base}/document/upload")
    print(f"[iVault] file: {display_name} ({file_size} bytes, {mime})")
    print(f"[iVault] form_data fields:")
    for k, v in form_data.items():
        print(f"         {k} = {v}")

    _upload_headers = {
        "Authorization":   auth_header,
        "Accept":          "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Origin":          f"https://{tenant}",
        "Referer":         f"https://{tenant}/",
        "Tenant":          tenant,
    }

    try:
        if upload_bytes:
            import io as _io
            upload_resp = session.post(
                f"{api_base}/document/upload",
                headers=_upload_headers,
                files={"files[0]": (display_name, _io.BytesIO(upload_bytes), mime)},
                data=form_data,
                timeout=60,
                verify=False,
            )
        else:
            with open(file_path, "rb") as f:
                upload_resp = session.post(
                    f"{api_base}/document/upload",
                    headers=_upload_headers,
                    files={"files[0]": (display_name, f, mime)},
                    data=form_data,
                    timeout=60,
                    verify=False,
                )

        print(f"[iVault] === Request headers sent ({len(upload_resp.request.headers)}) ===")
        for h, v in upload_resp.request.headers.items():
            if h.lower() == "authorization":
                print(f"         {h}: Bearer ***")
            else:
                print(f"         {h}: {v}")
        print(f"[iVault] upload status={upload_resp.status_code}")
        print(f"[iVault] response body: {upload_resp.text[:1000]}")

        if upload_resp.status_code not in (200, 201):
            try:
                detail = upload_resp.json()
            except ValueError:
                detail = upload_resp.text
            return jsonify({
                "error": f"iVault upload returned HTTP {upload_resp.status_code}",
                "detail": detail,
            }), 502

        try:
            upload_body = upload_resp.json()
        except ValueError:
            upload_body = {"raw": upload_resp.text}

    except req.exceptions.Timeout:
        return jsonify({"error": "iVault upload timed out (>60 s)"}), 504
    except req.exceptions.ConnectionError:
        return jsonify({"error": f"Cannot connect to iVault API at {api_base}"}), 502
    except req.exceptions.RequestException as e:
        return jsonify({"error": str(e)}), 502

    return jsonify({"success": True, "ivault_response": upload_body})


# ?????? POST /api/documents/ivault/import ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

def _push_fields_to_ivault(doc, doc_type, record_type_id, tenant, session, auth_header, api_base):
    """
    Push a processed Document's extracted fields to iVault as a new document
    under record_type_id, mapping DocumentField.external_property_id directly
    to the matching extracted value ??? no fuzzy name matching needed since
    doc_type was synced from this exact iVault class.

    Returns (success: bool, response_dict).
    """
    if not doc.unique_upload_filename:
        return False, {"error": "No source file stored for this document"}

    file_path = os.path.join(UPLOAD_FOLDER, doc.unique_upload_filename)
    if not os.path.exists(file_path):
        return False, {"error": "Source file not found on disk"}

    ext = doc.unique_upload_filename.rsplit(".", 1)[-1].lower()
    mime_map = {
        "pdf":  "application/pdf",
        "jpg":  "image/jpeg", "jpeg": "image/jpeg",
        "png":  "image/png",  "webp": "image/webp",
    }
    mime = mime_map.get(ext, "application/octet-stream")
    file_size = os.path.getsize(file_path)
    display_name = doc.filename or os.path.basename(file_path)

    doc_fields = doc.get_fields() or {}

    form_data = {
        "files[0][fileName]":  display_name,
        "files[0][extension]": mime,
        "files[0][size]":      str(file_size),
        "files[0][ext]":       ext,
        "files[0][classId]":   record_type_id,
    }

    i = 0
    for field in doc_type.fields:
        if not field.external_property_id:
            continue
        value = doc_fields.get(field.field_name, "")
        if value is None:
            value = ""
        elif isinstance(value, (dict, list)):
            value = json.dumps(value)
        p = f"files[0][properties][{i}]"
        form_data[f"{p}[classId]"]      = record_type_id
        form_data[f"{p}[propertyId]"]   = field.external_property_id
        form_data[f"{p}[propertyType]"] = str(field.external_property_type or 0)
        form_data[f"{p}[value]"]        = str(value)
        i += 1

    print(f"[iVault Import] pushing to: {api_base}/document/upload")
    print(f"[iVault Import] file: {display_name} ({file_size} bytes, {mime})")
    for k, v in form_data.items():
        print(f"         {k} = {v}")

    upload_headers = {
        "Authorization":   auth_header,
        "Accept":          "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Origin":          f"https://{tenant}",
        "Referer":         f"https://{tenant}/",
        "Tenant":          tenant,
    }

    import requests as req
    try:
        with open(file_path, "rb") as f:
            upload_resp = session.post(
                f"{api_base}/document/upload",
                headers=upload_headers,
                files={"files[0]": (display_name, f, mime)},
                data=form_data,
                timeout=60,
                verify=False,
            )
        print(f"[iVault Import] upload status={upload_resp.status_code}")
        print(f"[iVault Import] response body: {upload_resp.text[:1000]}")

        if upload_resp.status_code not in (200, 201):
            try:
                detail = upload_resp.json()
            except ValueError:
                detail = upload_resp.text
            return False, {"error": f"iVault upload returned HTTP {upload_resp.status_code}", "detail": detail}

        try:
            return True, upload_resp.json()
        except ValueError:
            return True, {"raw": upload_resp.text}
    except req.exceptions.RequestException as e:
        return False, {"error": str(e)}


def _run_ivault_import_task(job_id, file_index, file_path, original_filename, ext, unique_filename,
                             record_type_id, class_name, tenant, username, password, do_process, sync_back):
    """Background thread for /ivault/import ??? sync type, process, save, optionally push back."""
    from app import app
    from settings_routes import _sync_ivault_document_type

    with app.app_context():
        try:
            with jobs_lock:
                jobs[job_id]["files"][file_index]["status"]     = "processing"
                jobs[job_id]["files"][file_index]["started_at"] = time.time()
                jobs[job_id]["files"][file_index]["step"]       = "Connecting to iVault..."
                jobs[job_id]["files"][file_index]["step_num"]   = 0

            doc_type = DocumentType.query.filter_by(external_source="ivault", external_id=record_type_id).first()
            if doc_type is None:
                update_job_step(job_id, file_index, "Syncing record type from iVault...", 0.1)
                doc_type = _sync_ivault_document_type(record_type_id, class_name, tenant, username, password)

            _init_lm_progress(lambda label=None, frac=None, pages_done=None, pages_total=None:
                              update_job_step(job_id, file_index, label, frac, pages_done, pages_total))

            if do_process:
                update_job_step(job_id, file_index, "Processing with iProfiler...", 0.2)
                result = process_document(file_path, forced_document_type=doc_type.name)
            else:
                result = {
                    "document_type": doc_type.name,
                    "fields": {},
                    "raw_text": "",
                    "confidence": 0.0,
                    "text_blocks": None,
                }

            doc_dict = _save_document_to_db(result, original_filename, unique_filename, ext)

            ivault_push = None
            if sync_back and do_process:
                update_job_step(job_id, file_index, "Pushing results to iVault...", 0.95)
                try:
                    session, auth_header, api_base = _ivault_session(tenant, username, password)
                    doc = Document.query.get(doc_dict["id"])
                    ok, resp = _push_fields_to_ivault(doc, doc_type, record_type_id, tenant, session, auth_header, api_base)
                    ivault_push = {"success": ok, "response": resp}
                except IVaultAuthError as e:
                    ivault_push = {"success": False, "response": {"error": e.message}}

            doc_dict["ivault_push"] = ivault_push

            with jobs_lock:
                jobs[job_id]["files"][file_index]["status"] = "done"
                jobs[job_id]["files"][file_index]["result"] = doc_dict
                jobs[job_id]["status"] = "done"

        except Exception as e:
            with jobs_lock:
                jobs[job_id]["files"][file_index]["status"] = "error"
                jobs[job_id]["files"][file_index]["error"]  = str(e)
                jobs[job_id]["status"] = "done"


@document_bp.route("/ivault/import", methods=["POST"])
def ivault_import():
    """
    Import a document tied to a specific iVault record type.

    On first use of a given record_type_id, the iVault class is synced into
    a local DocumentType/DocumentField set (storing classId/propertyId) so
    extraction targets exactly those fields and results map back cleanly.

    Multipart form fields:
      file            ??? the document to import
      record_type_id  ??? iVault classId GUID
      class_name      ??? iVault class display name (used only if syncing for the first time)
      tenant          ??? iVault tenant host
      username        ??? iVault username
      password        ??? iVault password
      process         ??? "true"/"false" ??? run iProfiler extraction (default "true")
      sync_back       ??? "true"/"false" ??? push extracted fields back to iVault (default "false")

    Returns a job_id; track via the existing GET /api/documents/progress/<job_id> SSE stream.
    """
    import re as _re

    file = request.files.get("file")
    if not file or file.filename == "":
        return jsonify({"error": "No file provided"}), 400
    if not allowed_file(file.filename):
        return jsonify({"error": "Unsupported file type"}), 400

    record_type_id = (request.form.get("record_type_id") or "").strip()
    class_name      = (request.form.get("class_name") or "").strip()
    raw_tenant      = (request.form.get("tenant") or "").strip()
    tenant          = _re.sub(r'^https?://', '', raw_tenant).rstrip('/')
    username        = (request.form.get("username") or "").strip()
    password        = request.form.get("password") or ""
    do_process      = (request.form.get("process", "true").lower() in ("true", "1", "yes"))
    sync_back       = (request.form.get("sync_back", "false").lower() in ("true", "1", "yes"))

    if not record_type_id:
        return jsonify({"error": "record_type_id required"}), 400
    if not tenant or not username or not password:
        return jsonify({"error": "iVault credentials (tenant, username, password) required"}), 400

    original_filename = secure_filename(file.filename)
    ext               = original_filename.rsplit(".", 1)[1].lower()
    unique_filename   = f"{uuid.uuid4().hex}.{ext}"
    file_path         = os.path.join(UPLOAD_FOLDER, unique_filename)
    file.save(file_path)

    job_id = uuid.uuid4().hex
    job_files = [{
        "filename":        original_filename,
        "unique_filename": unique_filename,
        "file_path":       file_path,
        "ext":             ext,
        "status":      "pending",
        "step":        "Queued",
        "step_num":    0,
        "total_steps": 4,
        "started_at":  None,
        "result":      None,
        "sub_results": None,
        "error":       None,
    }]

    with jobs_lock:
        jobs[job_id] = {"status": "processing", "files": job_files}

    threading.Thread(
        target=_run_ivault_import_task,
        args=(job_id, 0, file_path, original_filename, ext, unique_filename,
              record_type_id, class_name, tenant, username, password, do_process, sync_back),
        daemon=True,
    ).start()

    return jsonify({"success": True, "job_id": job_id}), 202





