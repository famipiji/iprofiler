import os
import numpy as np
from PIL import Image
import pytesseract

# ── Tesseract path (Windows) ──────────────────────────────────────────────────
# Update this path if you installed Tesseract in a different location
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


# ── Tesseract (printed text + tables) ────────────────────────────────────────

def extract_with_tesseract(image_path: str) -> str:
    """
    Extract printed text and tables using Tesseract OCR.
    Best for: invoices, receipts, forms, scanned printed documents.
    """
    try:
        image = Image.open(image_path).convert("RGB")

        # PSM 6 = assume uniform block of text (good for full page docs)
        # OEM 3 = use LSTM neural network (most accurate)
        config = "--psm 6 --oem 3"

        text = pytesseract.image_to_string(image, config=config, lang="eng")
        return text.strip()

    except Exception as e:
        print(f"[OCR] Tesseract failed: {e}")
        return f"OCR extraction failed: {str(e)}"