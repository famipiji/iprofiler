﻿import json
from flask import Blueprint, request, jsonify
from extensions import db
from document_model import DocumentType, DocumentField, PromptTemplate, TenantRetentionPolicy, Document, PromptVersion, PromptVersionValidation
from prompt_studio_service import (
    ensure_prompt_version_seed,
    list_prompt_versions,
    get_schema_context,
    generate_merged_prompt,
    create_prompt_version,
    activate_prompt_version,
    rollback_prompt_version,
    diff_prompt_versions,
    test_prompt_version_against_sample,
)

settings_bp = Blueprint("settings", __name__)


def _encode_field_label(label: str, field_type: str, sub_columns) -> str:
    """
    For table-type fields, encode sub_columns into field_label as
    "Label\tJSON_ARRAY" so it persists without a DB schema migration.
    """
    label = (label or "").strip()
    if field_type == "table" and isinstance(sub_columns, list) and sub_columns:
        cols = [c for c in sub_columns if c and str(c).strip()]
        if cols:
            return label + "\t" + json.dumps(cols)
    return label


# ?????? Document Types ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@settings_bp.route("/document-types", methods=["GET"])
def list_document_types():
    types = DocumentType.query.order_by(DocumentType.created_at.desc()).all()
    return jsonify({"document_types": [t.to_dict() for t in types]})


@settings_bp.route("/document-types", methods=["POST"])
def create_document_type():
    data = request.get_json(force=True)
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "name is required"}), 400

    if DocumentType.query.filter_by(name=name).first():
        return jsonify({"error": f"Document type '{name}' already exists"}), 409

    dt = DocumentType(
        name=name,
        description=(data.get("description") or "").strip() or None,
        is_active=bool(data.get("is_active", True)),
    )
    db.session.add(dt)
    db.session.flush()

    for i, f in enumerate(data.get("fields", [])):
        field = DocumentField(
            document_type_id=dt.id,
            field_label=_encode_field_label(f.get("field_label", ""), f.get("field_type", "text"), f.get("sub_columns")),
            field_name=f.get("field_name", "").strip(),
            field_type=f.get("field_type", "text"),
            is_required=bool(f.get("is_required", False)),
            sort_order=i,
            aliases=(f.get("aliases") or "").strip() or None,
        )
        db.session.add(field)

    db.session.commit()
    return jsonify(dt.to_dict()), 201


@settings_bp.route("/document-types/<int:type_id>", methods=["GET"])
def get_document_type(type_id):
    dt = DocumentType.query.get_or_404(type_id)
    return jsonify(dt.to_dict())


@settings_bp.route("/document-types/<int:type_id>", methods=["PUT"])
def update_document_type(type_id):
    dt = DocumentType.query.get_or_404(type_id)
    data = request.get_json(force=True)

    name = (data.get("name") or "").strip()
    if name and name != dt.name:
        if DocumentType.query.filter_by(name=name).first():
            return jsonify({"error": f"Document type '{name}' already exists"}), 409
        dt.name = name

    if "description" in data:
        dt.description = (data["description"] or "").strip() or None
    if "is_active" in data:
        dt.is_active = bool(data["is_active"])

    if "fields" in data:
        DocumentField.query.filter_by(document_type_id=dt.id).delete()
        for i, f in enumerate(data["fields"]):
            field = DocumentField(
                document_type_id=dt.id,
                field_label=_encode_field_label(f.get("field_label", ""), f.get("field_type", "text"), f.get("sub_columns")),
                field_name=f.get("field_name", "").strip(),
                field_type=f.get("field_type", "text"),
                is_required=bool(f.get("is_required", False)),
                sort_order=i,
                aliases=(f.get("aliases") or "").strip() or None,
            )
            db.session.add(field)

    db.session.commit()
    return jsonify(dt.to_dict())


@settings_bp.route("/document-types/<int:type_id>", methods=["DELETE"])
def delete_document_type(type_id):
    dt = DocumentType.query.get_or_404(type_id)
    db.session.delete(dt)
    db.session.commit()
    return jsonify({"deleted": type_id})


@settings_bp.route("/document-types/<int:type_id>/toggle", methods=["POST"])
def toggle_document_type(type_id):
    dt = DocumentType.query.get_or_404(type_id)
    dt.is_active = not dt.is_active
    db.session.commit()
    return jsonify({"id": dt.id, "is_active": dt.is_active})


@settings_bp.route("/document-types/fields/<int:field_id>/aliases", methods=["PATCH"])
def patch_field_aliases(field_id):
    """Update the aliases for a single DocumentField (used by the ASK correction card)."""
    from document_model import DocumentField
    df = DocumentField.query.get_or_404(field_id)
    data = request.get_json() or {}
    aliases = (data.get("aliases") or "").strip() or None
    df.aliases = aliases
    db.session.commit()
    return jsonify({"ok": True, "field_id": field_id, "aliases": df.aliases or ""})


# ?????? Tenant Retention Policy ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@settings_bp.route("/retention-policy/<string:tenant_id>", methods=["GET"])
def get_retention_policy(tenant_id):
    policy = TenantRetentionPolicy.query.filter_by(tenant_id=tenant_id).first()
    if policy is None:
        policy = TenantRetentionPolicy(tenant_id=tenant_id, sample_ttl_days=7, production_ttl_days=30)
    return jsonify(policy.to_dict())


@settings_bp.route("/retention-policy/<string:tenant_id>", methods=["PUT"])
def update_retention_policy(tenant_id):
    data = request.get_json(force=True) or {}
    policy = TenantRetentionPolicy.query.filter_by(tenant_id=tenant_id).first()
    if policy is None:
        policy = TenantRetentionPolicy(tenant_id=tenant_id)
        db.session.add(policy)

    if "sample_ttl_days" in data:
        policy.sample_ttl_days = max(0, int(data["sample_ttl_days"]))
    if "production_ttl_days" in data:
        policy.production_ttl_days = max(0, int(data["production_ttl_days"]))

    db.session.commit()
    return jsonify(policy.to_dict())


# ?????? Prompt Versions ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@settings_bp.route("/prompt-versions/<string:doc_type>", methods=["GET"])
def list_prompt_versions_route(doc_type):
    try:
        ensure_prompt_version_seed(doc_type)
    except Exception:
        pass

    versions = list_prompt_versions(doc_type)
    doc = DocumentType.query.filter(db.func.lower(DocumentType.name) == doc_type.lower()).first()
    sample_docs = []
    if doc:
        sample_docs = Document.query.filter_by(document_type=doc.name, document_class="sample").order_by(Document.created_at.desc()).all()

    return jsonify({
        "document_type": doc.to_dict() if doc else None,
        "versions": [v.to_dict() for v in versions],
        "sample_documents": [d.to_dict() for d in sample_docs],
        "schema_context": get_schema_context(doc_type),
    })


@settings_bp.route("/prompt-versions/<string:doc_type>/merge", methods=["POST"])
def merge_prompt_version(doc_type):
    data = request.get_json(force=True) or {}
    user_feedback = (data.get("user_feedback") or "").strip()
    if not user_feedback:
        return jsonify({"error": "user_feedback is required"}), 400

    doc = DocumentType.query.filter(db.func.lower(DocumentType.name) == doc_type.lower()).first()
    if doc is None:
        return jsonify({"error": "document type not found"}), 404

    base_version = None
    if data.get("base_version_id"):
        base_version = PromptVersion.query.get(data["base_version_id"])
    if base_version is None:
        ensure_prompt_version_seed(doc_type)
        base_version = PromptVersion.query.get(doc.active_prompt_version_id)

    sample_document = None
    if data.get("sample_document_id"):
        sample_document = Document.query.get(data["sample_document_id"])

    evidence_context = {
        "sample_document_id": sample_document.id if sample_document else None,
        "sample_document_filename": sample_document.filename if sample_document else None,
    }

    merged = generate_merged_prompt(
        base_version.prompt_text if base_version else "",
        user_feedback,
        get_schema_context(doc_type),
        evidence_context=evidence_context,
    )

    return jsonify({
        "base_version": base_version.to_dict() if base_version else None,
        "proposed_prompt": merged["merged_prompt"],
        "change_summary": merged["change_summary"],
        "notes": merged.get("notes"),
    })


@settings_bp.route("/prompt-versions/<string:doc_type>", methods=["POST"])
def create_prompt_version_route(doc_type):
    data = request.get_json(force=True) or {}
    prompt_text = (data.get("prompt_text") or "").strip()
    if not prompt_text:
        return jsonify({"error": "prompt_text is required"}), 400

    version = create_prompt_version(
        doc_type,
        prompt_text,
        change_summary=(data.get("change_summary") or "").strip() or None,
        created_by=(data.get("created_by") or "system").strip(),
        parent_version_id=data.get("parent_version_id"),
        bump=(data.get("bump") or "minor").strip().lower(),
    )

    if bool(data.get("activate", False)):
        version = activate_prompt_version(version.id)

    return jsonify(version.to_dict()), 201


@settings_bp.route("/prompt-versions/<int:version_id>/rollback", methods=["POST"])
def rollback_prompt_version_route(version_id):
    version = PromptVersion.query.get_or_404(version_id)
    result = rollback_prompt_version(version.document_type.name, version.id)
    return jsonify(result.to_dict())


@settings_bp.route("/prompt-versions/<int:version_id>", methods=["DELETE"])
def delete_prompt_version_route(version_id):
    version = PromptVersion.query.get_or_404(version_id)
    if version.is_active:
        return jsonify({"error": "Cannot delete the active version. Rollback to another version first."}), 400
    doc_type = version.document_type
    PromptVersionValidation.query.filter_by(prompt_version_id=version_id).delete()
    db.session.delete(version)
    db.session.commit()
    versions = list_prompt_versions(doc_type.name) if doc_type else []
    return jsonify({"success": True, "versions": [v.to_dict() for v in versions]})


@settings_bp.route("/prompt-versions/diff", methods=["GET"])
def diff_prompt_versions_route():
    left_id = request.args.get("left_id", type=int)
    right_id = request.args.get("right_id", type=int)
    if not left_id or not right_id:
        return jsonify({"error": "left_id and right_id are required"}), 400

    left = PromptVersion.query.get_or_404(left_id)
    right = PromptVersion.query.get_or_404(right_id)
    return jsonify({
        "left": left.to_dict(),
        "right": right.to_dict(),
        "diff": diff_prompt_versions(left, right),
    })


@settings_bp.route("/prompt-versions/<int:version_id>/test-extraction", methods=["POST"])
def test_prompt_version_route(version_id):
    data = request.get_json(force=True) or {}
    sample_document_id = data.get("sample_document_id")
    if not sample_document_id:
        return jsonify({"error": "sample_document_id is required"}), 400

    try:
        result = test_prompt_version_against_sample(
            version_id,
            int(sample_document_id),
            created_by=(data.get("created_by") or "system").strip(),
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ?????? Prompt Manager ????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

@settings_bp.route("/prompts", methods=["GET"])
def list_prompts():
    prompts = PromptTemplate.query.order_by(PromptTemplate.category, PromptTemplate.label).all()
    return jsonify({"prompts": [p.to_dict() for p in prompts]})


@settings_bp.route("/prompts/<int:prompt_id>", methods=["PUT"])
def update_prompt(prompt_id):
    prompt = PromptTemplate.query.get_or_404(prompt_id)
    data = request.get_json(force=True) or {}

    content = data.get("content")
    if content is None or not content.strip():
        return jsonify({"error": "content is required"}), 400

    prompt.content = content
    db.session.commit()
    return jsonify(prompt.to_dict())


@settings_bp.route("/prompts/<int:prompt_id>/reset", methods=["POST"])
def reset_prompt(prompt_id):
    prompt = PromptTemplate.query.get_or_404(prompt_id)

    from qwen_service import OCR_HINTS, DOCUMENT_STRUCTURE_HINTS, DEFAULT_CLASSIFY_PROMPT, EXTRACT_PROMPTS
    if prompt.category == "ocr_hint":
        default = OCR_HINTS.get(prompt.doc_type)
    elif prompt.category == "structure_hint":
        default = DOCUMENT_STRUCTURE_HINTS.get(prompt.doc_type)
    elif prompt.category == "classify":
        default = DEFAULT_CLASSIFY_PROMPT
    elif prompt.category == "extract":
        entry = EXTRACT_PROMPTS.get(prompt.key)
        default = entry[1] if entry else None
    else:
        default = None

    if default is None:
        return jsonify({"error": "no built-in default available for this prompt"}), 400

    prompt.content = default
    db.session.commit()
    return jsonify(prompt.to_dict())


# ?????? iVault sync ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

import re as _re

_CURRENCY_HINTS = ("amount", "total", "price", "balance", "tax", "subtotal", "cost", "fee")
_DATE_HINTS = ("date", "_dob", "expiry", "expiration")


def _snake_case(s: str) -> str:
    s = _re.sub(r'[^A-Za-z0-9]+', '_', str(s or "")).strip('_')
    s = _re.sub(r'(?<!^)(?=[A-Z])', '_', s)
    return s.lower()


def _field_type_for_property(field_name: str) -> str:
    n = field_name.lower()
    if any(h in n for h in _DATE_HINTS):
        return "date"
    if any(h in n for h in _CURRENCY_HINTS):
        return "currency"
    return "text"


def _sync_ivault_document_type(record_type_id: str, class_name: str, tenant: str, username: str, password: str) -> DocumentType:
    """
    Sync an iVault record type (Class + classPropertyModels) into a
    DocumentType/DocumentField pair, storing iVault's classId/propertyId
    so extraction + push-back can target this type directly. Idempotent.

    Raises document_routes.IVaultAuthError on login failure, or RuntimeError
    on other iVault API errors. Must be called within an app context.
    """
    from document_routes import _ivault_session

    session, auth_header, api_base = _ivault_session(tenant, username, password)
    return _sync_ivault_document_type_with_session(record_type_id, class_name, session, auth_header, api_base, tenant)


def _sync_ivault_document_type_with_session(record_type_id: str, class_name: str, session, auth_header: str, api_base: str, tenant: str) -> DocumentType:
    """
    Same as _sync_ivault_document_type(), but reuses an already-authenticated
    iVault session ??? used by sync-ivault-all to sync many record types with
    a single login. Raises RuntimeError on iVault API errors.
    """
    cp_resp = session.get(
        f"{api_base}/Class/{record_type_id}",
        headers={"Authorization": auth_header, "Tenant": tenant},
        timeout=15,
        verify=False,
    )
    if not cp_resp.ok:
        raise RuntimeError(f"Failed to fetch iVault class definition (HTTP {cp_resp.status_code})")
    class_props = cp_resp.json().get("classPropertyModels", [])

    # Find-or-create the DocumentType for this iVault class
    dt = DocumentType.query.filter_by(external_source="ivault", external_id=record_type_id).first()
    if dt is None:
        type_name = _snake_case(class_name) or f"ivault_{record_type_id[:8]}"
        # Avoid clashing with an unrelated existing type of the same name
        if DocumentType.query.filter_by(name=type_name).first():
            type_name = f"ivault_{type_name}"
        dt = DocumentType(
            name=type_name,
            description=f"Synced from iVault: {class_name}",
            is_active=True,
            is_builtin=False,
            external_source="ivault",
            external_id=record_type_id,
        )
        db.session.add(dt)
        db.session.flush()

    # Sync fields: find-or-create by external_property_id, drop stale ones
    seen_property_ids = set()
    for i, prop in enumerate(class_props):
        prop_id = str(prop.get("propertyId", "")).strip()
        prop_name = prop.get("propertyName", "")
        if not prop_id or not prop_name:
            continue
        seen_property_ids.add(prop_id)

        field_name = _snake_case(prop_name)
        prop_type = prop.get("type", 0)

        field = DocumentField.query.filter_by(document_type_id=dt.id, external_property_id=prop_id).first()
        if field is None:
            field = DocumentField(
                document_type_id=dt.id,
                field_label=prop_name,
                field_name=field_name,
                field_type=_field_type_for_property(field_name),
                is_required=False,
                sort_order=i,
                external_property_id=prop_id,
                external_property_type=prop_type,
            )
            db.session.add(field)
        else:
            field.field_label = prop_name
            field.field_name = field_name
            field.sort_order = i
            field.external_property_type = prop_type

    # Remove fields whose iVault property no longer exists
    for field in list(dt.fields):
        if field.external_property_id and field.external_property_id not in seen_property_ids:
            db.session.delete(field)

    db.session.commit()
    return dt


@settings_bp.route("/document-types/sync-ivault", methods=["POST"])
def sync_ivault_document_type():
    """
    Sync an iVault record type (Class + classPropertyModels) into a
    DocumentType/DocumentField pair, storing iVault's classId/propertyId
    so extraction + push-back can target this type directly.

    Body: {
      "record_type_id": "<iVault classId GUID>",
      "class_name":     "AP Invoice",
      "tenant":         "demo.ivaultplus.com",
      "username":       "sys.admin",
      "password":       "secret"
    }
    """
    from document_routes import IVaultAuthError

    data = request.get_json(force=True) or {}
    record_type_id = (data.get("record_type_id") or "").strip()
    class_name = (data.get("class_name") or "").strip()
    tenant = _re.sub(r'^https?://', '', (data.get("tenant") or "").strip()).rstrip('/')
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    if not record_type_id:
        return jsonify({"error": "record_type_id required"}), 400
    if not class_name:
        return jsonify({"error": "class_name required"}), 400
    if not tenant or not username or not password:
        return jsonify({"error": "iVault credentials (tenant, username, password) required"}), 400

    try:
        dt = _sync_ivault_document_type(record_type_id, class_name, tenant, username, password)
    except IVaultAuthError as e:
        return jsonify({"error": e.message}), e.status
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 502

    return jsonify({"document_type": dt.to_dict()})


@settings_bp.route("/document-types/sync-ivault-all", methods=["POST"])
def sync_ivault_all_document_types():
    """
    Fetch the full list of record types (Classes) from iVault and sync each
    one into a DocumentType/DocumentField set (same as sync-ivault, but for
    every class in one call using a single login).

    Body: {
      "tenant":   "demo.ivaultplus.com",
      "username": "sys.admin",
      "password": "secret"
    }
    """
    from document_routes import IVaultAuthError, _ivault_session

    data = request.get_json(force=True) or {}
    tenant = _re.sub(r'^https?://', '', (data.get("tenant") or "").strip()).rstrip('/')
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    if not tenant or not username or not password:
        return jsonify({"error": "iVault credentials (tenant, username, password) required"}), 400

    try:
        session, auth_header, api_base = _ivault_session(tenant, username, password)
    except IVaultAuthError as e:
        return jsonify({"error": e.message}), e.status

    try:
        list_resp = session.get(
            f"{api_base}/Class/list",
            headers={"Authorization": auth_header, "Tenant": tenant},
            timeout=15,
            verify=False,
        )
        if not list_resp.ok:
            return jsonify({"error": f"Failed to fetch iVault class list (HTTP {list_resp.status_code})"}), 502
        raw = list_resp.json()
        items = raw if isinstance(raw, list) else raw.get("data", raw.get("classes", raw.get("items", [])))
    except Exception as e:
        return jsonify({"error": f"Failed to fetch iVault class list: {e}"}), 502

    synced = []
    errors = []
    for item in items:
        cid = str(item.get("classId") or item.get("ClassId") or item.get("id") or item.get("Id") or "").strip()
        cname = (item.get("className") or item.get("ClassName") or item.get("name") or item.get("Name") or "").strip()
        if not cid or not cname:
            continue
        try:
            dt = _sync_ivault_document_type_with_session(cid, cname, session, auth_header, api_base, tenant)
            synced.append(dt.to_dict())
        except Exception as e:
            errors.append({"class_name": cname, "error": str(e)})

    return jsonify({"document_types": synced, "errors": errors})

